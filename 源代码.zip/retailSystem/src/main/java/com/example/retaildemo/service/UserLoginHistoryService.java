package com.example.retaildemo.service;

import com.example.retaildemo.beans.UserLoginHistory;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 登录历史表  服务类
 * </p>
 *
 * @author 唐华星
 * @since 2024-11-12
 */
public interface UserLoginHistoryService extends IService<UserLoginHistory> {

}
