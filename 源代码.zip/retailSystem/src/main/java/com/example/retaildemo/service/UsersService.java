package com.example.retaildemo.service;

import com.example.retaildemo.beans.Users;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.retaildemo.vo.ResultVO;

/**
 * <p>
 * 用户  服务类
 * </p>
 *
 * @author 唐华星
 * @since 2024-11-12
 */
public interface UsersService extends IService<Users> {

    ResultVO userResgit(String name, String pwd);

    ResultVO checkLogin(String name, String pwd);

    Users findByName(String name);

    // 新增的方法：通过ID查询用户信息
    Users findById(Integer id);  // 这里传入的是 Integer 类型的 ID
}
