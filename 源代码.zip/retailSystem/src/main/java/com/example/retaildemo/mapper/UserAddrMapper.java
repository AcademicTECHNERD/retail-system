package com.example.retaildemo.mapper;

import com.example.retaildemo.beans.UserAddr;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 用户地址  Mapper 接口
 * </p>
 *
 * @author 唐华星
 * @since 2024-11-12
 */
public interface UserAddrMapper extends BaseMapper<UserAddr> {

}
