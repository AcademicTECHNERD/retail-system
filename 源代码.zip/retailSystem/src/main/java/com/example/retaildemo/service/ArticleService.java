package com.example.retaildemo.service;

import com.example.retaildemo.beans.Article;
import com.example.retaildemo.vo.ResultVO;

import java.util.List;

public interface ArticleService {
    ResultVO addArticle(Article article);
    List<Article> getAllArticles();
    Article getArticleById(Long id);
    ResultVO updateArticle(Article article);
    ResultVO deleteArticle(Long id);
}
