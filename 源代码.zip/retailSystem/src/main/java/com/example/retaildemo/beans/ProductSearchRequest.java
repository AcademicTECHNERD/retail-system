package com.example.retaildemo.beans;

import lombok.Data;

import java.util.List;
@Data
public class ProductSearchRequest {
    private String keyword; // 搜索关键词
    private List<String> userAnswers; // 用户选择的筛选条件（如品牌、产地等）

    // Getters 和 Setters
}
