package com.example.retaildemo.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel(value = "MerchantProductVO对象", description = "封装商家商品展示数据")
public class MerchantProductVO {

    @ApiModelProperty(value = "商品ID")
    private String id; // 对应 product.product_id

    @ApiModelProperty(value = "商品名称")
    private String name; // 对应 product.product_name

    @ApiModelProperty(value = "销量")
    private Integer sales; // 对应 product.sold_num

    @ApiModelProperty(value = "库存")
    private Integer stock; // 来自 product_sku.stock

    @ApiModelProperty(value = "销售价格")
    private Integer sellPrice; // 来自 product_sku.sell_price

    @ApiModelProperty(value = "原价")
    private Integer originalPrice; // 来自 product_sku.original_price

    @ApiModelProperty(value = "折扣")
    private Double discount; // 来自 product_sku.discounts
}
