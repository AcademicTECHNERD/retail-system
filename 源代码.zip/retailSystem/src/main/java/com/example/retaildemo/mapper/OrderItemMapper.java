package com.example.retaildemo.mapper;

import com.example.retaildemo.beans.OrderItem;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 订单项/快照  Mapper 接口
 * </p>
 *
 * @author 唐华星
 * @since 2024-11-12
 */
public interface OrderItemMapper extends BaseMapper<OrderItem> {

}
