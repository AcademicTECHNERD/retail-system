package com.example.retaildemo.controller;

import com.example.retaildemo.beans.CategoryQuestion;
import com.example.retaildemo.service.CategoryQuestionService;
import com.example.retaildemo.vo.QuestionResponseVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/search")
public class SearchController {

    @Autowired
    private CategoryQuestionService categoryQuestionService;

    @GetMapping
    public QuestionResponseVO search(@RequestParam("keyword") String keyword) {
        // 1. 根据关键词查找相关问题
        List<CategoryQuestion> questions = categoryQuestionService.findQuestionsByKeyword(keyword);
        if (questions.isEmpty()) {
            return QuestionResponseVO.noCategoryFound(); // 如果没有找到相关问题
        }

        // 2. 返回结果
        return QuestionResponseVO.success(questions);
    }
}
