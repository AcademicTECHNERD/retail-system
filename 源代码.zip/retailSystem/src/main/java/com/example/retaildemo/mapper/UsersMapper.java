package com.example.retaildemo.mapper;

import com.example.retaildemo.beans.Users;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Select;

/**
 * <p>
 * 用户  Mapper 接口
 * </p>
 *
 * @author 唐华星
 * @since 2024-11-12
 */
public interface UsersMapper extends BaseMapper<Users> {
    @Select("SELECT * FROM users WHERE user_id = #{id}")
    Users findById(Integer id);
}
