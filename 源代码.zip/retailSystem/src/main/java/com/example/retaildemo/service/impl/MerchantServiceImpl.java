package com.example.retaildemo.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.retaildemo.beans.Product;
import com.example.retaildemo.mapper.MerchantMapper;
import com.example.retaildemo.service.MerchantService;
import com.example.retaildemo.vo.MerchantProductVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MerchantServiceImpl extends ServiceImpl<MerchantMapper, Product> implements MerchantService {

    @Autowired
    private MerchantMapper merchantMapper;

    @Override
    public List<MerchantProductVO> getProductsByMerchant(String merchantId) {
        return merchantMapper.selectProductsByMerchant(merchantId);
    }
}
