package com.example.retaildemo.service.impl;

import com.example.retaildemo.beans.Category;
import com.example.retaildemo.beans.CategoryQuestion;
import com.example.retaildemo.service.CategoryQuestionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Service
public class CategoryQuestionServiceImpl implements CategoryQuestionService {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public List<CategoryQuestion> findQuestionsByKeyword(String keyword) {
        // Step 1: 根据关键词查询分类
        String categorySql = "SELECT * FROM category WHERE category_name LIKE ? LIMIT 1";
        Category category = null;
        try {
            category = jdbcTemplate.queryForObject(categorySql, new Object[]{"%" + keyword + "%"}, new RowMapper<Category>() {
                @Override
                public Category mapRow(ResultSet rs, int rowNum) throws SQLException {
                    Category cat = new Category();
                    cat.setCategoryId(rs.getInt("category_id"));
                    cat.setCategoryName(rs.getString("category_name"));
                    cat.setCategoryLevel(rs.getInt("category_level"));
                    cat.setParentId(rs.getInt("parent_id"));
                    return cat;
                }
            });
        } catch (Exception e) {
            // 查询失败时处理
            e.printStackTrace();
        }

        if (category == null) {
            // 如果没有找到对应的分类，返回空列表
            return List.of();
        }

        // Step 2: 根据找到的 category_id 查找问题
        Integer mainCategoryId = (category.getCategoryLevel() == 1) ? category.getCategoryId() : category.getParentId();
        String questionSql = "SELECT * FROM category_question WHERE category_id = ? AND is_active = 1";

        // Step 3: 返回找到的问题
        try {
            return jdbcTemplate.query(questionSql, new Object[]{mainCategoryId}, new RowMapper<CategoryQuestion>() {
                @Override
                public CategoryQuestion mapRow(ResultSet rs, int rowNum) throws SQLException {
                    CategoryQuestion question = new CategoryQuestion();
                    question.setQuestionId(rs.getInt("question_id"));
                    question.setCategoryId(rs.getInt("category_id"));
                    question.setQuestion(rs.getString("question"));
                    question.setQuestionType(rs.getString("question_type"));
                    question.setOptions(rs.getString("options"));
                    question.setCreateTime(rs.getTimestamp("create_time").toLocalDateTime());
                    question.setUpdateTime(rs.getTimestamp("update_time") != null ? rs.getTimestamp("update_time").toLocalDateTime() : null);
                    question.setIsActive(rs.getBoolean("is_active"));
                    return question;
                }
            });
        } catch (Exception e) {
            // 查询失败时处理
            e.printStackTrace();
            return List.of(); // 返回空列表
        }
    }

    @Override
    public List<CategoryQuestion> findQuestionsByCategoryId(Integer categoryId) {
        // 如果需要，可以实现此方法。这里只是返回空列表
        return List.of();
    }
}
