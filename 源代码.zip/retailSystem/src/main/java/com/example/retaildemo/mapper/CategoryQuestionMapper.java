package com.example.retaildemo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.retaildemo.beans.CategoryQuestion;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CategoryQuestionMapper extends BaseMapper<CategoryQuestion> {
}
