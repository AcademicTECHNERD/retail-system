package com.example.retaildemo.mapper;

import com.example.retaildemo.beans.ArticleComment;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;
@Mapper
public interface ArticleCommentMapper {

    // 插入评论
    @Insert("INSERT INTO article_comment (article_id, user_id, content, parent_id, create_time, update_time) " +
            "VALUES (#{articleId}, #{userId}, #{content}, #{parentId}, #{createTime}, #{updateTime})")
    int insertComment(ArticleComment comment);

    // 查询某篇文章的所有评论
    @Select("SELECT * FROM article_comment WHERE article_id = #{articleId} ORDER BY create_time DESC")
    List<ArticleComment> selectCommentsByArticleId(Integer articleId);
}
