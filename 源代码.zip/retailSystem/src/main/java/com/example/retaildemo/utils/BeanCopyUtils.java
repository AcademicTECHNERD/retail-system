package com.example.retaildemo.utils;

import org.springframework.beans.BeanUtils;

public class BeanCopyUtils {
    /**
     * 将源对象的属性复制到目标对象
     * @param source 源对象
     * @param targetClass 目标对象的类类型
     * @param <T> 目标对象类型
     * @return 目标对象
     */
    public static <T> T copyProperties(Object source, Class<T> targetClass) {
        try {
            T target = targetClass.getDeclaredConstructor().newInstance();
            BeanUtils.copyProperties(source, target);
            return target;
        } catch (Exception e) {
            throw new RuntimeException("Bean copy error", e);
        }
    }
}
