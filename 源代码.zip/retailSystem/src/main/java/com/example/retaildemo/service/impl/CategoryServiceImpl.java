package com.example.retaildemo.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.example.retaildemo.beans.Category;
import com.example.retaildemo.mapper.CategoryMapper;
import com.example.retaildemo.service.CategoryService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.retaildemo.vo.CategoryVO;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * <p>
 * 商品分类 服务实现类
 * </p>
 *
 * @author 唐华星
 * @since 2024-11-12
 */
@Service
public class CategoryServiceImpl extends ServiceImpl<CategoryMapper, Category> implements CategoryService {
    @Resource
    private CategoryMapper categoryMapper;
    @Override
    public List<CategoryVO> categoryAll(){
        List<Category> categoriesList = categoryMapper.selectList(null);
        ArrayList<CategoryVO> objects = new ArrayList<>();
        for (Category category : categoriesList) {
            CategoryVO categoryVO = new CategoryVO();
            BeanUtils.copyProperties(category,categoryVO);
            objects.add(categoryVO);
        }
        return setcategories(objects);
    }

    //找子分类,构建子菜单
    public List<CategoryVO> setcategories(List<CategoryVO> categoryVOList) {
        // 获取一级分类
        List<CategoryVO> levelOneCategories = new ArrayList<>();
        for (Category category : categoryMapper.selectList(new QueryWrapper<Category>().eq("category_level", 1))) {
            CategoryVO categoryVO = new CategoryVO();
            BeanUtils.copyProperties(category, categoryVO);
            levelOneCategories.add(categoryVO);
        }

        // 创建父子分类的关系映射
        Map<Integer, List<CategoryVO>> categoryMap = categoryVOList.stream()
                .collect(Collectors.groupingBy(CategoryVO::getParentId));

        // 给一级分类添加子分类
        for (CategoryVO categoryVO : levelOneCategories) {
            categoryVO.setCategories(categoryMap.get(categoryVO.getCategoryId()));
        }

        return levelOneCategories;
    }

    //递归分类
    public void recursion(List<CategoryVO> categoryVOList,CategoryVO categoryVO){
        List<CategoryVO> getcategories = getcategories(categoryVOList, categoryVO);
        categoryVO.setCategories(getcategories);
        if (getcategories.size()>0){
            for (CategoryVO getcategory : getcategories) {
                recursion(categoryVOList,getcategory);
            }
        }
    }
    //获取子菜单
    public List<CategoryVO> getcategories(List<CategoryVO> categoryVOList,CategoryVO categoryVO){
        ArrayList<CategoryVO> categoryVOS = new ArrayList<>();
        Iterator<CategoryVO> iterator = categoryVOList.iterator();
        //hasNext():判断是否存在下一个元素
        //		while(iter.hasNext()){
        //			//如果存在，则调用next实现迭代
        while (iterator.hasNext()) {
            CategoryVO next = iterator.next();
            if(next.getParentId().equals(categoryVO.getCategoryId())){
                categoryVOS.add(next);
            }
        }
        return categoryVOS;
    }

}
