package com.example.retaildemo.service.impl;

import com.example.retaildemo.beans.ArticleComment;
import com.example.retaildemo.mapper.ArticleCommentMapper;
import com.example.retaildemo.service.ArticleCommentService;
import com.example.retaildemo.vo.ResultVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class ArticleCommentServiceImpl implements ArticleCommentService {

    @Autowired
    private ArticleCommentMapper articleCommentMapper;

    @Override
    public ResultVO addComment(ArticleComment comment) {
        // 设置创建和更新时间
        comment.setCreateTime(new Date());
        comment.setUpdateTime(new Date());

        // 插入评论到数据库
        int result = articleCommentMapper.insertComment(comment);

        if (result > 0) {
            return new ResultVO(10000, "评论成功！", comment);
        } else {
            return new ResultVO(10001, "评论失败！", null);
        }
    }

    @Override
    public List<ArticleComment> getCommentsByArticleId(Integer articleId) {
        return articleCommentMapper.selectCommentsByArticleId(articleId);
    }
}
