package com.example.retaildemo.service;

import com.example.retaildemo.beans.ProductImg;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 商品图片  服务类
 * </p>
 *
 * @author 唐华星
 * @since 2024-11-12
 */
public interface ProductImgService extends IService<ProductImg> {

}
