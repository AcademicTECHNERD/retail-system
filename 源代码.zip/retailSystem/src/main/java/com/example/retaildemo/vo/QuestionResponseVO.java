package com.example.retaildemo.vo;

import com.example.retaildemo.beans.CategoryQuestion;
import lombok.Data;

import java.util.List;

@Data
public class QuestionResponseVO {
    private Boolean success;
    private String message;
    private List<CategoryQuestion> questions;

    public static QuestionResponseVO success(List<CategoryQuestion> questions) {
        QuestionResponseVO response = new QuestionResponseVO();
        response.setSuccess(true);
        response.setMessage("Questions retrieved successfully.");
        response.setQuestions(questions);
        return response;
    }

    public static QuestionResponseVO noCategoryFound() {
        QuestionResponseVO response = new QuestionResponseVO();
        response.setSuccess(false);
        response.setMessage("No matching category found.");
        response.setQuestions(null);
        return response;
    }
}
