package com.example.retaildemo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.retaildemo.beans.Product;
import com.example.retaildemo.vo.MerchantProductVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface MerchantMapper extends BaseMapper<Product> {

    @Select("SELECT " +
            "p.product_id AS id, " +
            "p.product_name AS name, " +
            "p.sold_num AS sales, " +
            "ps.stock AS stock, " +
            "ps.sell_price AS sellPrice, " +
            "ps.original_price AS originalPrice, " +
            "ps.discounts AS discount " +
            "FROM merchant m " +
            "JOIN product p ON m.merchant_id = p.merchant_id " +
            "LEFT JOIN product_sku ps ON p.product_id = ps.product_id " +
            "WHERE m.merchant_id = 20080707")
    List<MerchantProductVO> selectProductsByMerchant(@Param("merchantId") String merchantId);
}
