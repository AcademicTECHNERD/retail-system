package com.example.retaildemo.beans;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class CategoryQuestion {
    @ApiModelProperty(value = "问题主键")
    @TableId(value = "question_id", type = IdType.ASSIGN_UUID)
    private Integer questionId;

    @ApiModelProperty(value = "商品分类ID")
    private Integer categoryId;

    @ApiModelProperty(value = "问题内容")
    private String question;

    @ApiModelProperty(value = "问题类型")
    private String questionType;

    @ApiModelProperty(value = "问题选项（JSON格式）")
    private String options;

    @ApiModelProperty(value = "创建时间")
    private LocalDateTime createTime;

    @ApiModelProperty(value = "更新时间")
    private LocalDateTime updateTime;

    @ApiModelProperty(value = "是否激活")
    private Boolean isActive;
}