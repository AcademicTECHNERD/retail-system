package com.example.retaildemo.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.retaildemo.beans.ProductComments;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.retaildemo.vo.ProductCommentsVO;

import java.util.List;

/**
 * <p>
 * 商品评价  服务类
 * </p>
 *
 * @author 唐华星
 * @since 2024-11-12
 */
public interface ProductCommentsService extends IService<ProductComments> {
    Page<ProductCommentsVO> showComments(String ProductId,Page<ProductCommentsVO> page);
}
