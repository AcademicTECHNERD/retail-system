package com.example.retaildemo.beans;

import lombok.Data;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.Date;

/**
 * 文章实体
 */
@Data
@ApiModel(value = "Article", description = "文章对象")
public class Article {

//    @ApiModelProperty(value = "文章ID")
//    private Long id;
//
//    @ApiModelProperty(value = "文章标题")
//    private String title;
//
//    @ApiModelProperty(value = "文章内容")
//    private String content;
//
//    @ApiModelProperty(value = "封面图片")
//    private String coverImg;
//
//    @ApiModelProperty(value = "分类名称")
//    private String categoryName; // 分类名称
//
//    @ApiModelProperty(value = "创建人")
//    private String username; // 创建人用户名
//
//    @ApiModelProperty(value = "文章状态")
//    private String state;
//
//    @ApiModelProperty(value = "分类ID")
//    private Integer categoryId;
//
//    @ApiModelProperty(value = "创建用户")
//    private Integer createUser;
//
//    @ApiModelProperty(value = "创建时间")
//    private Date createTime;
//
//    @ApiModelProperty(value = "更新时间")
//    private Date updateTime;

    private Long id;
    private String title;
    private String content;
    private String coverImg;
    private String state;
    private Integer categoryId;
    private String categoryName; // 分类名称
    private Integer userId;
    private String username; // 创建人用户名
    private Date createTime;
    private Date updateTime;
    private String command;
}
