package com.example.retaildemo.mapper;

import com.example.retaildemo.beans.Orders;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.retaildemo.vo.ResultVO;

/**
 * <p>
 * 订单  Mapper 接口
 * </p>
 *
 * @author 唐华星
 * @since 2024-11-12
 */
public interface OrdersMapper extends BaseMapper<Orders> {

}
