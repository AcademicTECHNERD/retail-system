package com.example.retaildemo.vo;

import lombok.Data;

import java.util.List;

@Data
public class SearchData {
    private String keyword;            // 搜索关键词
    private List<String> userAnswers;  // 用户选择的答案，包含品牌、产地、内容等
}
