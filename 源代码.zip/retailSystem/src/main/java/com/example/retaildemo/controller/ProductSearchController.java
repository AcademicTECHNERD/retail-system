package com.example.retaildemo.controller;

import com.example.retaildemo.service.ProductSearchService;
import com.example.retaildemo.vo.ResultVO;
import com.example.retaildemo.vo.ProductVO;
import com.example.retaildemo.vo.SearchData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/retaildemo/products")
public class ProductSearchController {

    @Autowired
    private ProductSearchService productSearchService;

    /**
     * 基于搜索关键词查询商品
     * @param keyword 搜索词
     * @return 商品列表
     */
    @PostMapping("/search")
    public ResultVO searchByKeyword(@RequestBody String keyword) {
        List<ProductVO> products = productSearchService.searchByKeyword(keyword);
        if (products.isEmpty()) {
            return new ResultVO(404, "未找到商品", null);
        }
        return new ResultVO(200, "查询成功", products);
    }

    /**
     * 基于搜索关键词和用户选择的选项查询商品
     * @param searchData 包含搜索词和用户选项
     * @return 商品列表
     */
    @PostMapping("/searchWithAnswers")
    public ResultVO searchWithAnswers(@RequestBody SearchData searchData) {
        List<ProductVO> products = productSearchService.searchWithAnswers(searchData);
        if (products.isEmpty()) {
            return new ResultVO(404, "未找到商品", null);
        }
        return new ResultVO(200, "查询成功", products);
    }
}
