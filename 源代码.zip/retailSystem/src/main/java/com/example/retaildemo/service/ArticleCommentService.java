package com.example.retaildemo.service;

import com.example.retaildemo.beans.ArticleComment;
import com.example.retaildemo.vo.ResultVO;

import java.util.List;

public interface ArticleCommentService {

    // 添加评论
    ResultVO addComment(ArticleComment comment);

    // 获取某篇文章的所有评论
    List<ArticleComment> getCommentsByArticleId(Integer articleId);
}
