package com.example.retaildemo.service;

import com.example.retaildemo.beans.Orders;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.retaildemo.vo.ResultVO;

/**
 * <p>
 * 订单  服务类
 * </p>
 *
 * @author 唐华星
 * @since 2024-11-12
 */
public interface OrdersService extends IService<Orders> {
    String addOrder(String cartId, Orders order);

    String queryOrder(String orderNo);

    void checkOrderStatus(String orderNo);

    String tradeCreate(String orderId);
}
