package com.example.retaildemo.mapper;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.retaildemo.beans.Product;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.retaildemo.beans.ProductParams;
import com.example.retaildemo.vo.PriceImg;
import com.example.retaildemo.vo.ProductCommentsVO;
import com.example.retaildemo.vo.ProductVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * <p>
 * 商品 商品信息相关表：分类表，商品图片表，商品规格表，商品参数表 Mapper 接口
 * </p>
 *
 * @author 唐华星
 * @since 2024-11-12
 */
@Mapper
public interface ProductMapper extends BaseMapper<Product> {
    @Select(" select distinct p.product_name,p.product_id,p.sold_num,p.content,p.category_id, i.url,s.sell_price\n" +
            " from product p  INNER JOIN product_img i INNER JOIN product_sku s \n" +
            "            on i.item_id=p.product_id and s.product_id=p.product_id \n" +
            "            where p.category_id=#{categoryId} and i.is_main=1")
List<PriceImg> getByCategoryId(@Param("categoryId") String categoryId, Page<PriceImg> page);
    @Select(" select distinct p.product_name,p.product_id,p.sold_num,p.content,p.category_id, i.url,s.sell_price\n" +
            " from product p  INNER JOIN product_img i INNER JOIN product_sku s \n" +
            "            on i.item_id=p.product_id and s.product_id=p.product_id \n" +
            "            where p.product_name like concat('%',#{keyword},'%') and i.is_main=1")
    List<PriceImg> fuzzyQuery(@Param("keyword") String keyword,Page<PriceImg> page);

    @Select("SELECT p.product_name, p.product_id, p.sold_num, p.content, p.category_id, i.url, s.sell_price " +
            "FROM product p " +
            "INNER JOIN product_img i ON i.item_id = p.product_id " +
            "INNER JOIN product_sku s ON s.product_id = p.product_id " +
            "WHERE p.product_id IN (${productIds}) AND i.is_main = 1")
    List<PriceImg> searchByProductIds(Page<PriceImg> page, String productIds);

    /**
     * 通过商品名称（模糊查询）查找商品
     *
     * @param keyword 商品名称关键字
     * @return 商品列表
     */
    List<Product> findByKeyword(@Param("keyword") String keyword);

    /**
     * 根据商品的ID查询商品的详细参数
     *
     * @param productId 商品ID
     * @return 商品的参数信息
     */
    ProductParams findParamsByProductId(@Param("productId") String productId);

    /**
     * 通过商品名称、品牌、产地、商品内容等条件查询商品
     * 这里包含了三个筛选条件：品牌、产地和商品内容（即用户的选项）
     *
     * @param keyword 搜索的关键字
     * @param brand 品牌
     * @param productPlace 产地
     * @param content 商品内容
     * @return 商品列表
     */
    List<Product> searchWithFilters(
            @Param("keyword") String keyword,
            @Param("brand") String brand,
            @Param("productPlace") String productPlace,
            @Param("content") String content
    );

    /**
     * 查询商品的ID和名称，返回基本的商品信息
     *
     * @param keyword 搜索的商品名称
     * @return 商品的简要信息
     */
    List<Product> searchBasicInfoByKeyword(@Param("keyword") String keyword);
}
