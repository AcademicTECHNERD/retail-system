package com.example.retaildemo.controller;

import com.example.retaildemo.service.MerchantService;
import com.example.retaildemo.vo.MerchantProductVO;
import com.example.retaildemo.vo.ResultVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/merchantmanage/goods")
public class MerchantController {

    @Autowired
    private MerchantService merchantService;

    @GetMapping("/all")
    public ResultVO getAllGoods(@RequestParam("merchant_id") String merchantId) {
        List<MerchantProductVO> products = merchantService.getProductsByMerchant(merchantId);
        return new ResultVO(10000, "成功", products);
    }
}
