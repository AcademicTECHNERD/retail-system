package com.example.retaildemo.mapper;

import com.example.retaildemo.beans.ArticleCategory;
import com.example.retaildemo.beans.ArticleCategory;
import org.apache.ibatis.annotations.*;

import java.util.List;
/**
 * <p>
 * 文章分类 Mapper 接口
 * </p>
 *
 * @author 唐华星
 * @since 2024-11-12
 */
@Mapper
public interface ArticleCategoryMapper {
    //新增
    @Insert("insert into articlecategory(category_name,category_alias,create_user,create_time,update_time) " +
            "values(#{categoryName},#{categoryAlias},#{createUsle},#{createTime},#{updateTime})")
    void add(ArticleCategory articalCategory);

//    //查询所有
//    @Select("select * from articlecategory where create_user = #{userId}")
//    List<ArticleCategory> list(Integer userId);

    //查询所有
    @Select("select * from articlecategory")
    List<ArticleCategory> list();

    //根据id查询
    @Select("select * from articlecategory where id = #{id}")
    ArticleCategory findById(Integer id);

    //更新
    @Update("update articlecategory set category_name=#{categoryName},category_alias=#{categoryAlias},update_time=#{updateTime} where id=#{id}")
    void update(ArticleCategory articalCategory);

    //根据id删除
    @Delete("delete from articlecategory where id=#{id}")
    void deleteById(Integer id);
}
