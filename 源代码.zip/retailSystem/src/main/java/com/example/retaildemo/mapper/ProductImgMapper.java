package com.example.retaildemo.mapper;

import com.example.retaildemo.beans.ProductImg;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 商品图片  Mapper 接口
 * </p>
 *
 * @author 唐华星
 * @since 2024-11-12
 */
public interface ProductImgMapper extends BaseMapper<ProductImg> {

}
