package com.example.retaildemo.mapper;

import com.example.retaildemo.beans.Article;
import org.apache.ibatis.annotations.*;

import java.util.List;
/**
 * <p>
 * 文章 Mapper 接口
 * </p>
 *
 * @author 唐华星
 * @since 2024-11-12
 */
@Mapper
public interface ArticleMapper {
    // 新增文章
    @Insert("insert into article(title, content, cover_img, state, category_id, user_id, create_time, update_time) " +
            "values(#{title}, #{content}, #{coverImg}, #{state}, #{categoryId}, #{createUser}, #{createTime}, #{updateTime}, #{command})")
    void add(Article article);

    // 查询所有文章
    @Select("SELECT * FROM article WHERE state = #{state} AND (category_id = #{categoryId} OR category_id IS NULL)")
    List<Article> list(@Param("userId") Integer userId, @Param("categoryId") Integer categoryId, @Param("state") String state);

//    @Select("SELECT * FROM article")
//    List<Article> listAll();

    @Select("SELECT " +
            "a.*, " +
            "c.category_name AS categoryName, " +
            "u.username AS username " +
            "FROM article a " +
            "LEFT JOIN articlecategory c ON a.category_id = c.id " +
            "LEFT JOIN users u ON a.user_id = u.user_id")
    List<Article> listAll();

    // 查询单个文章
    @Select("SELECT * FROM article WHERE id = #{id}")
    Article findById(Long id); // 添加findById方法

    // 更新文章
    @Update("UPDATE article SET title=#{title}, content=#{content}, cover_img=#{coverImg}, state=#{state}, " +
            "category_id=#{categoryId}, update_time=#{updateTime} WHERE id=#{id}")
    void update(Article article); // 添加update方法

    // 删除文章
    @Delete("DELETE FROM article WHERE id = #{id}")
    void deleteById(Long id);



//    // 删除文章
//    @Delete("DELETE FROM article WHERE id = #{id}")
//    void deleteById(Long id);

}
