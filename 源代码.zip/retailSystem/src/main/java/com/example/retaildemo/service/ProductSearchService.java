package com.example.retaildemo.service;

import com.example.retaildemo.vo.ProductVO;
import com.example.retaildemo.beans.Product;
import com.example.retaildemo.vo.SearchData;

import java.util.List;

public interface ProductSearchService {
    /**
     * 基于搜索关键词查询商品
     * @param keyword 搜索关键词
     * @return 商品列表
     */
    List<ProductVO> searchByKeyword(String keyword);

    /**
     * 基于搜索关键词和用户选择的选项查询商品
     * @param searchData 包含搜索词和用户选择的选项
     * @return 商品列表
     */
    List<ProductVO> searchWithAnswers(SearchData searchData);
}
