package com.example.retaildemo.beans;

import java.util.Date;

/**
 * 评论实体类
 */
public class ArticleComment {

    private Integer id;           // 评论ID
    private Integer articleId;    // 文章ID
    private Integer userId;       // 用户ID（评论者）
    private String content;       // 评论内容
    private Integer parentId;     // 父评论ID（如果是回复评论，则会有值）
    private Date createTime;      // 评论时间
    private Date updateTime;      // 修改时间

    // Getters and Setters...

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getArticleId() {
        return articleId;
    }

    public void setArticleId(Integer articleId) {
        this.articleId = articleId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Integer getParentId() {
        return parentId;
    }

    public void setParentId(Integer parentId) {
        this.parentId = parentId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
}
