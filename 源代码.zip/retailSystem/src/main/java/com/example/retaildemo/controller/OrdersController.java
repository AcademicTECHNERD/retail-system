package com.example.retaildemo.controller;

import com.alibaba.fastjson.JSONObject;
import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.AlipayConstants;
import com.alipay.api.internal.util.AlipaySignature;
import com.alipay.api.request.AlipayTradePagePayRequest;
import com.alipay.api.response.AlipayTradePagePayResponse;
import com.example.retaildemo.beans.Orders;
import com.example.retaildemo.service.OrdersService;
import com.example.retaildemo.vo.ResultVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.Map;

/**
 * <p>
 * 订单  前端控制器
 * </p>
 *
 * @author
 * @since 2024-11-12
 */
@RestController
@RequestMapping("/retaildemo/orders")
@Api(tags = "订单管理")
@Slf4j
public class OrdersController {

    @Autowired
    private OrdersService ordersService;

    @Resource
    private AlipayClient alipayClient;

    // 从配置文件中注入支付宝相关配置
    @Value("${alipay.notifyUrl}")
    private String notifyUrl;

    @Value("${alipay.returnUrl}")
    private String returnUrl;

    @Value("${alipay.appId}")
    private String configuredAppId;

    @Value("${alipay.alipayPublicKey}")
    private String configuredAlipayPublicKey;

    // 如果需要卖家ID，也可配置（若YML里没有可设置默认值）
    @Value("${alipay.sellerId:2088721061188365}")
    private String sellerIdProperty;

    @PostMapping(value = "/add", produces = "text/html;charset=utf-8")
    @ApiOperation("购物车结算生成订单,返回支付宝支付链接")
    public String add(String cartId, @RequestBody Orders orders, @RequestHeader("token") String token) {
        String orderId = ordersService.addOrder(cartId, orders);
        try {
            AlipayTradePagePayRequest request = new AlipayTradePagePayRequest();
            Orders orderInfo = ordersService.getById(orderId);
            JSONObject bizContent = new JSONObject();
            // 使用配置文件中的 notifyUrl 与 returnUrl
            request.setNotifyUrl(notifyUrl);
            request.setReturnUrl(returnUrl + "?orderId=" + orderId);
            bizContent.put("out_trade_no", orderInfo.getOrderId());
            BigDecimal total = new BigDecimal(orderInfo.getActualAmount());
            bizContent.put("total_amount", total);
            bizContent.put("subject", orderInfo.getUntitled());
            bizContent.put("product_code", "FAST_INSTANT_TRADE_PAY");
            request.setBizContent(bizContent.toString());
            AlipayTradePagePayResponse response = alipayClient.pageExecute(request);
            if (response.isSuccess()) {
                return response.getBody();
            } else {
                throw new RuntimeException("创建支付交易失败");
            }
        } catch (AlipayApiException e) {
            log.error("创建支付交易异常", e);
            throw new RuntimeException("创建支付交易失败");
        }
    }

    @ApiOperation("支付通知")
    @PostMapping("/trade/notify")
    public String tradeNotify(@RequestParam Map<String, String> params) {
        String result = "failure";
        try {
            // 使用支付宝 SDK 进行异步通知验签，公钥从配置中读取
            boolean signVerified = AlipaySignature.rsaCheckV1(
                    params,
                    configuredAlipayPublicKey,
                    AlipayConstants.CHARSET_UTF8,
                    AlipayConstants.SIGN_TYPE_RSA2
            );
            if (!signVerified) {
                log.error("支付宝异步通知验签失败: {}", params);
                return result;
            }
            // 验签成功后，进行业务数据校验
            String outTradeNo = params.get("out_trade_no");
            Orders order = ordersService.getById(outTradeNo);
            if (order == null) {
                return result;
            }
            // 判断 total_amount 是否与订单实际金额一致
            String totalAmount = params.get("total_amount");
            int totalAmountInt = new BigDecimal(totalAmount).intValue();
            int totalFeeInt = order.getActualAmount();
            if (totalAmountInt != totalFeeInt) {
                log.error("金额校验失败: 通知金额 {} 与订单金额 {} 不符", totalAmountInt, totalFeeInt);
                return result;
            }
            // 校验通知中的 seller_id 是否正确
            String sellerId = params.get("seller_id");
            if (!sellerId.equals(sellerIdProperty)) {
                log.error("sellerId 校验失败: {}", sellerId);
                return result;
            }
            // 验证 app_id 是否与配置一致
            String appId = params.get("app_id");
            if (!appId.equals(configuredAppId)) {
                log.error("appId 校验失败: {}", appId);
                return result;
            }
            // 只有交易状态为 TRADE_SUCCESS 才认为支付成功
            String tradeStatus = params.get("trade_status");
            if (!"TRADE_SUCCESS".equals(tradeStatus)) {
                return result;
            }
            // 所有校验通过
            result = "success";
        } catch (AlipayApiException e) {
            log.error("支付通知验签异常", e);
        }
        return result;
    }

    @GetMapping("/getOrder")
    @ApiOperation("通过订单ID获取信息")
    public ResultVO getInfo(@RequestParam String orderId, @RequestHeader("token") String token) {
        Orders order = ordersService.getById(orderId);
        return new ResultVO(10000, "获取订单信息成功", order);
    }
}
