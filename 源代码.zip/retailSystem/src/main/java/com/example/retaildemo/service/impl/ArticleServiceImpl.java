package com.example.retaildemo.service.impl;

import com.example.retaildemo.beans.Article;
import com.example.retaildemo.mapper.ArticleMapper;
import com.example.retaildemo.service.ArticleService;
import com.example.retaildemo.vo.ResultVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
/**
 * <p>
 * 文章帖子 服务实现类
 * </p>
 *
 * @author 唐华星
 * @since 2024-11-12
 */
@Service
public class ArticleServiceImpl implements ArticleService {

    @Autowired
    private ArticleMapper articleMapper;

    @Override
    public ResultVO addArticle(Article article) {
        try {
            articleMapper.add(article);
            return new ResultVO(200, "添加文章成功", null);
        } catch (Exception e) {
            return new ResultVO(500, "添加文章失败: " + e.getMessage(), null);
        }
    }

    @Override
    public List<Article> getAllArticles() {
        return articleMapper.listAll();
    }


    @Override
    public Article getArticleById(Long id) {
        return articleMapper.findById(id);
    }

    @Override
    public ResultVO updateArticle(Article article) {
        try {
            articleMapper.update(article);
            return new ResultVO(200, "更新文章成功", null);
        } catch (Exception e) {
            return new ResultVO(500, "更新文章失败: " + e.getMessage(), null);
        }
    }

    @Override
    public ResultVO deleteArticle(Long id) {
        try {
            articleMapper.deleteById(id);
            return new ResultVO(200, "删除文章成功", null);
        } catch (Exception e) {
            return new ResultVO(500, "删除文章失败: " + e.getMessage(), null);
        }
    }
}
