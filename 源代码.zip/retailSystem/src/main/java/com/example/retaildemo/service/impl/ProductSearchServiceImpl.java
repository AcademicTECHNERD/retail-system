package com.example.retaildemo.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.retaildemo.beans.Product;
import com.example.retaildemo.beans.ProductParams;
import com.example.retaildemo.mapper.ProductMapper;
import com.example.retaildemo.mapper.ProductParamsMapper;
import com.example.retaildemo.service.ProductSearchService;
import com.example.retaildemo.vo.ProductVO;
import com.example.retaildemo.vo.SearchData;
import com.example.retaildemo.utils.BeanCopyUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ProductSearchServiceImpl extends ServiceImpl<ProductMapper, Product> implements ProductSearchService {

    @Autowired
    private ProductMapper productMapper;

    @Autowired
    private ProductParamsMapper productParamsMapper;

    @Override
    public List<ProductVO> searchByKeyword(String keyword) {
        // 构建查询条件，基于商品名称进行模糊查询
        QueryWrapper<Product> queryWrapper = new QueryWrapper<>();
        queryWrapper.like("product_name", keyword).eq("product_status", 1);

        List<Product> products = productMapper.selectList(queryWrapper);
        return convertToProductVO(products);
    }

    @Override
    public List<ProductVO> searchWithAnswers(SearchData searchData) {
        String keyword = searchData.getKeyword();
        List<String> userAnswers = searchData.getUserAnswers();

        // Step 1: 基于关键词查询产品
        QueryWrapper<Product> queryWrapper = new QueryWrapper<>();
        queryWrapper.like("product_name", keyword).eq("product_status", 1);
        List<Product> products = productMapper.selectList(queryWrapper);

        // 如果根据关键词没有找到商品
        if (products.isEmpty()) {
            return new ArrayList<>();
        }

        // Step 2: 根据用户选择的选项进行过滤
        List<Product> filteredProducts = new ArrayList<>();
        for (Product product : products) {
            boolean matches = true;

            // 筛选条件: 选项1 (品牌), 选项2 (产地), 选项3 (商品内容)
            if (userAnswers.size() > 0 && !userAnswers.get(0).isEmpty()) {
                ProductParams params = getProductParams(product.getProductId());
                if (!params.getBrand().contains(userAnswers.get(0))) {
                    matches = false;
                }
            }

            if (userAnswers.size() > 1 && !userAnswers.get(1).isEmpty()) {
                ProductParams params = getProductParams(product.getProductId());
                if (!params.getProductPlace().contains(userAnswers.get(1))) {
                    matches = false;
                }
            }

            if (userAnswers.size() > 2 && !userAnswers.get(2).isEmpty()) {
                if (!product.getContent().contains(userAnswers.get(2))) {
                    matches = false;
                }
            }

            // 如果符合筛选条件则保留
            if (matches) {
                filteredProducts.add(product);
            }
        }

        // Step 3: 将结果转换为VO对象
        return convertToProductVO(filteredProducts);
    }

    // 将Product对象转换为ProductVO
    private List<ProductVO> convertToProductVO(List<Product> products) {
        List<ProductVO> productVOList = new ArrayList<>();
        for (Product product : products) {
            ProductVO productVO = BeanCopyUtils.copyProperties(product, ProductVO.class);
            productVOList.add(productVO);
        }
        return productVOList;
    }

    // 获取商品的详细参数
    private ProductParams getProductParams(String productId) {
        QueryWrapper<ProductParams> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("product_id", productId);

        // 查询多条记录
        List<ProductParams> paramsList = productParamsMapper.selectList(queryWrapper);

        if (paramsList.isEmpty()) {
            return null;  // 如果没有找到结果，返回null
        }

        if (paramsList.size() > 1) {
            // 返回第一条记录，假设后续不会出现这种情况
            return paramsList.get(0);
        }

        // 返回第一条记录
        return paramsList.get(0);
    }

}
