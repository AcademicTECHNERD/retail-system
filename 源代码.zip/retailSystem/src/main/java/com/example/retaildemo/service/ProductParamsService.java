package com.example.retaildemo.service;

import com.example.retaildemo.beans.ProductParams;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 商品参数  服务类
 * </p>
 *
 * @author 唐华星
 * @since 2024-11-12
 */
public interface ProductParamsService extends IService<ProductParams> {
ProductParams getById(String s);
}

