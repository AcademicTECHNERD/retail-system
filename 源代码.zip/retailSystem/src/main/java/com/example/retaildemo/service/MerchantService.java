package com.example.retaildemo.service;

import com.example.retaildemo.vo.MerchantProductVO;
import java.util.List;

public interface MerchantService {
    List<MerchantProductVO> getProductsByMerchant(String merchantId);
}
