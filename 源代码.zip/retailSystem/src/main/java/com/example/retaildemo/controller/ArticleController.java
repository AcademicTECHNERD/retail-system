package com.example.retaildemo.controller;

import com.example.retaildemo.beans.Article;
import com.example.retaildemo.beans.ArticleComment;
import com.example.retaildemo.service.ArticleCommentService;
import com.example.retaildemo.service.ArticleService;
import com.example.retaildemo.vo.ResultVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
/**
 * <p>
 * 文章 前端控制器
 * </p>
 *
 * @author 唐华星
 * @since 2024-11-12
 */
@RestController
@RequestMapping("/retaildemo/article")
public class ArticleController {

    @Autowired
    private ArticleService articleService;

    @PostMapping("/add")
    public ResultVO addArticle(@RequestBody Article article) {
        return articleService.addArticle(article);
    }

    @GetMapping("/all")
    public List<Article> getAllArticles() {
        return articleService.getAllArticles();
    }


    @GetMapping("/{id}")
    public Article getArticleById(@PathVariable Long id) {
        return articleService.getArticleById(id);
    }

    @PutMapping("/update")
    public ResultVO updateArticle(@RequestBody Article article) {
        return articleService.updateArticle(article);
    }

    @DeleteMapping("/{id}")
    public ResultVO deleteArticle(@PathVariable Long id) {
        return articleService.deleteArticle(id);
    }

    @Autowired
    private ArticleCommentService articleCommentService;

    // 获取文章评论接口
    @GetMapping("/{articleId}/comments")
    public List<ArticleComment> getCommentsByArticleId(@PathVariable Integer articleId) {
        return articleCommentService.getCommentsByArticleId(articleId);
    }

    // 添加文章评论接口
    @PostMapping("/{articleId}/comment")
    public ResultVO addComment(@PathVariable Integer articleId, @RequestBody ArticleComment comment) {
        comment.setArticleId(articleId);  // 设置文章ID
        return articleCommentService.addComment(comment);
    }
}
