package com.example.retaildemo.mapper;

import com.example.retaildemo.beans.ProductParams;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * 商品参数  Mapper 接口
 * </p>
 *
 * @author 唐华星
 * @since 2024-11-12
 */
@Mapper
public interface ProductParamsMapper extends BaseMapper<ProductParams> {

}
