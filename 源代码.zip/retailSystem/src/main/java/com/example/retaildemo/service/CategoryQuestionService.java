package com.example.retaildemo.service;

import com.example.retaildemo.beans.CategoryQuestion;

import java.util.List;

public interface CategoryQuestionService {
    List<CategoryQuestion> findQuestionsByKeyword(String keyword);

    List<CategoryQuestion> findQuestionsByCategoryId(Integer categoryId);
}
