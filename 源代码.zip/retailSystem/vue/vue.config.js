// vue.config.js
module.exports = {
    chainWebpack: (config) => {
      config.module
        .rule('transpile-marked')
        .test(/\.js$/)
        // 将需要转译 marked 模块的部分加入 include
        .include.add(/node_modules[\\/]marked/).end()
        .use('babel-loader')
        .loader('babel-loader')
        .options({
          // 如果有额外的 Babel 配置也可以在这里配置，
          // 但一般情况下它会自动读取 babel.config.js
        });
    }
  };
  