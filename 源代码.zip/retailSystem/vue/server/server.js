const express = require('express');
const axios = require('axios');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

const config = {
  API_PASSWORD: "UahVcPFeiHcDYmkUStEZ:wewFjeiptyhWjOndzEGb", // 请在讯飞开放平台控制台获取
  API_HOST: "spark-api-open.xf-yun.com",
  API_PATH: "/v1/chat/completions",
  MODEL: "4.0Ultra"  // 指定模型版本
};

app.post('/api/chat', async (req, res) => {
  try {
    // 整理请求体，注意这里可根据需求调整默认参数值
    const requestBody = {
      model: config.MODEL,
      messages: req.body.messages.map(msg => ({
        role: msg.role,
        content: msg.content
      })),
      temperature: req.body.parameters?.temperature || 0.5,
      max_tokens: req.body.parameters?.max_tokens || 2048,
      top_k: req.body.parameters?.top_k || 4
    };

    const url = `https://${config.API_HOST}${config.API_PATH}`;

    const response = await axios.post(url, requestBody, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${config.API_PASSWORD}`
      },
      timeout: 60000  // 60 秒超时
    });

    res.json(response.data);
  } catch (error) {
    console.error('错误：', error.response?.data || error.message);
    res.status(500).json({
      error: error.response?.data?.message || '服务器内部错误'
    });
  }
});

app.listen(3001, () => console.log('服务运行中，监听端口 3001'));
