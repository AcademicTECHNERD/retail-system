import axios from 'axios'

// 文章分类列表查询
// export const articleCategoryListService = (userId) => {
//     return axios.get(`http://localhost:9090/retaildemo/article-category/list/${userId}`)
// }
// 文章分类列表查询
export const articleCategoryListService = (userId) => {
    return axios.get(`http://localhost:9090/retaildemo/article-category/list/${userId}`)
}

// 文章分类添加
export const articleCategoryAddService = (categoryData) => {
    return axios.post('http://localhost:9090/retaildemo/article-category/add', categoryData)
}

// 文章分类修改
export const articleCategoryUpdateService = (categoryData) => {
    return axios.put('http://localhost:9090/retaildemo/article-category/update', categoryData)
}

// 文章分类删除
export const articleCategoryDeleteService = (id) => {
    return axios.delete(`http://localhost:9090/retaildemo/article-category/${id}`)
}

// 文章管理的编辑
export const articleUpdateService = (articleData) => {
    return axios.put('http://localhost:9090/retaildemo/article/update', articleData)
}

// 文章管理的删除
export const articleDeleteService = (id) => {
    return axios.delete(`http://localhost:9090/retaildemo/article/${id}`)
}

// 文章列表查询
export const articleListService = (params) => {
    return axios.get('http://localhost:9090/retaildemo/article/list', { params: params })
}

// 文章添加
export const articleAddService = (articleData) => {
    return axios.post('http://localhost:9090/retaildemo/article/add', articleData)
}
