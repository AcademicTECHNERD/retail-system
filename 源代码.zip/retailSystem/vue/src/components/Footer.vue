<template>
  <div>
  <div>
    <el-link type="info">关于我们</el-link>
    <el-divider direction="vertical"></el-divider>
    <el-link type="info">联系我们</el-link>
    <el-divider direction="vertical"></el-divider>
    <el-link type="info">商家入驻</el-link>
    <el-divider direction="vertical"></el-divider>
    <el-link type="info">帮助中心</el-link>
    <el-divider direction="vertical"></el-divider>
    <el-link type="info">友情链接</el-link>
    <el-divider direction="vertical"></el-divider>
    <el-link type="info">网站指南</el-link>
  </div>
  <div>
    <el-link type="info" >备案信息</el-link>
  </div>
  </div>
</template>

<script>
export default {
  name: "",
};
</script>

<style >
</style>
