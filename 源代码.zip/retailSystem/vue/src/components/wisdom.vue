<template>
    <div>
        <!-- 导航栏开始 -->
        <div class="cha">
            <ul id="nav">
                <li v-for="(item, index) in menuItems" :key="index" class="nav-item"
                    @mouseenter="toggleDropdown(index, true)" @mouseleave="toggleDropdown(index, false)">
                    <a href="#">{{ item.name }}</a>
                    <ul v-show="item.showDropdown" class="submenu">
                        <li v-for="(subItem, subIndex) in item.submenu" :key="subIndex">
                            <a :href="subItem.link">{{ subItem.name }}</a>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
        <!-- 导航栏结束 -->
    </div>
</template>

<script>
export default {
    name: "NavBar",
    data() {
        return {
            menuItems: [
                {
                    name: "不知道买啥",
                    submenu: [
                        { name: "试衣间", link: "#" },
                        { name: "热门帖子", link: "#" },
                        { name: "品牌历史", link: "/BrandHistory" },
                    ],
                    showDropdown: false,
                },
                {
                    name: "避坑小工具",
                    submenu: [
                        { name: "AI推荐", link: "/AI_model" },
                        { name: "商品研究", link: "#" },
                        { name: "记账本", link: "/cashbook" },
                    ],
                    showDropdown: false,
                },
                // 其他菜单项
            ],
        };
    },
    methods: {
        toggleDropdown(index, show) {
            this.menuItems[index].showDropdown = show;
        },
    },
};
</script>

<style scoped>
/* 去除列表项的默认序号和边距 */
#nav {
    list-style-type: none;
    /* 去掉序点 */
    padding: 0;
    /* 去掉内边距 */
    margin: 0;
    /* 去掉外边距 */
    margin-right: 100px;
}

.nav-item {
    position: relative;
    width: 90px;
    height: 55px;
    line-height: 55px;
    text-align: center;
    float: right;
    margin-right: 20px;
}

.nav-item a {
    color: white;
    text-decoration: none;
}

/* .nav-item a:hover {
    background-color: #235049;
} */

/* 下拉菜单的样式 */
.submenu {
    display: none;
    position: absolute;
    width: 180px;
    left: -45px;
    /* background-color: pink; */
    padding: 0;
    margin: 0;
}

.submenu li {
    height: 50px;
    line-height: 50px;
    list-style: none;
}

.submenu li a {
    color: white;
    text-decoration: none;
    display: block;
    /* 使链接占满整个子菜单项 */
    padding: 0 10px;
    transition: background-color 0.3s ease;
}

/* 显示子菜单 */
.nav-item:hover .submenu {
    display: block;
}

/* 鼠标悬停时改变子菜单项的背景颜色 */
.submenu li:hover {
    background-color: pink;
}
</style>