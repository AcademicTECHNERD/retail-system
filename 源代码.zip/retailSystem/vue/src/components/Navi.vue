<template>
  <div>
    <div style="background-color: #e6e4e3;">
      <el-row style="width: 80%; margin: 0 auto">
        <el-col :span="12" style="margin-top: 5px; margin-bottom: 5px">
          <div v-if="!username" style="float: left">
            <el-link :underline="false" @click="login">登录</el-link>
            <el-divider direction="vertical"></el-divider>
            <el-link :underline="false" href="/register">注册</el-link>
          </div>
          <div v-else style="float: left">
            <el-dropdown>
              <span class="el-dropdown-link">
                <el-link :underline="false" href="/person">欢迎您：{{ username }}，您的角色是:{{root}}</el-link> <i class="el-icon-arrow-down el-icon--right"></i>
              </span>
              <el-dropdown-menu slot="dropdown">
                <el-dropdown-item style="width: 150px; height: 60px">
                  <el-row :gutter="20">
                    <el-col :span="8">
                      <el-avatar :src="'http://localhost:9090/img/' + img" style="margin-top: 5px"></el-avatar>
                    </el-col>
                    <el-col :span="16">
                      <el-link :underline="false" href="/person">个人中心</el-link>
                      <el-link :underline="false" @click="logout">退出登录</el-link>
                    </el-col>
                  </el-row>
                </el-dropdown-item>
              </el-dropdown-menu>
            </el-dropdown>
            <el-divider direction="vertical"></el-divider>
          </div>
        </el-col>
        <el-col :span="12" style="margin-top: 5px; margin-bottom: 5px">
          <div style="float: right">
            <el-divider direction="vertical"></el-divider>
            <el-link :underline="false" href="/HomeView">智慧搜索</el-link>
            <el-divider direction="vertical"></el-divider>
            <el-link :underline="false" href="/ArticleHome">解疑社区</el-link>
            <el-divider direction="vertical"></el-divider>
            <el-link :underline="false" href="/">商城首页</el-link>
            <el-divider direction="vertical"></el-divider>
            <el-link :underline="false" :href="'/orderList?uid=' + userId" icon="el-icon-circle-check">我的订单</el-link>
            <el-divider direction="vertical"></el-divider>
            <el-link :underline="false" :href="'/shopcart?uid=' + userId" icon="el-icon-shopping-cart-2">我的购物车</el-link>
            <el-divider direction="vertical"></el-divider>
            <el-link :underline="false" href="/history">我的足迹</el-link>
            <!-- 动态显示商家后台按钮 -->
            <el-divider direction="vertical"></el-divider>
            <el-link :underline="false" href="/merchantHome" v-if="isBusiness">商家后台</el-link>
          </div>
        </el-col>
      </el-row>
    </div>
  </div>
</template>
 
<script>
import router from "@/router";
 
export default {
  name: "Navi",
  data() {
    return {
      username: localStorage.getItem("username"), 
      img: localStorage.getItem("img"), 
      userId: localStorage.getItem("userId"), 
      input: "",
      select: "",
      root: localStorage.getItem("root"),  // 获取用户的root权限 
      isBusiness: localStorage.getItem("root")  === 'business', // 判断是否为商家 
    };
  },
  computed: {
    // 可选：使用计算属性来判断 
    isBusinessComputed() {
      return this.root  === 'business';
    }
  },
  methods: {
    logout() {
      localStorage.removeItem("username"); 
      localStorage.removeItem("img"); 
      localStorage.removeItem("token"); 
      localStorage.removeItem("userId"); 
      this.$message.success(" 退出成功");
      this.username  = "";
      this.isBusiness  = false; // 更新状态 
    },
    login() {
      router.push({ 
        path: '/login',
        query: {
          redirect: router.currentRoute.fullPath  // 防止从外部进来登录
        }
      })
    },
    fuzzyQuery(){
      router.push({
        path: '/search',
        query:{
          keyword:this.input  // 防止从外部进来登录
        }
      })
    },
    search(v){
      router.push({
        path: '/search',
        query:{
          keyword:v  // 防止从外部进来登录
        }
      })
    }
  }
}
</script>

<style scoped>

</style>