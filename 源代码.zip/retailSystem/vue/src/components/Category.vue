<template>
  <!-- 商品分类导航 -->
  <div>
    <div class="type-nav">
      <div class="container">
        <div class="sort">
          <div class="all-sort-list2">
            <div class="item" v-for="c1 in cata" :key="c1.categoryId">
              <h3>
                <i>
                  <!-- 使用相对路径引入图片 -->
                  <img :src="getCategoryIcon(c1.categoryIcon)"
                    style="vertical-align:middle;width: 30px; border-radius: 50%; position: relative; margin-right: 10px;">
                </i>
                <a>{{ c1.categoryName }}</a>
              </h3>
              <div class="item-list clearfix">
                <div class="subitem" v-for="c2 in c1.categories" :key="c2.categoryId">
                  <dl class="fore">
                    <dt><a>{{ c2.categoryName }}</a></dt>
                    <dd>
                      <em v-for="c3 in c2.categories" :key="c3.categoryId">
                        <a :href="'/search/?cid=' + c3.categoryId">{{ c3.categoryName }}</a>
                      </em>
                    </dd>
                  </dl>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from "axios";
import { baseURL } from "../../public/urlConfig";

export default {
  name: "Category",
  data() {
    return {
      cata: []
    };
  },
  mounted() {
    this.load();
  },
  methods: {
    load() {
      axios.get(baseURL + "/category/categories").then(res => {
        this.cata = res.data;
      });
    },
    // 处理分类图标的相对路径
    getCategoryIcon(iconName) {
      return require(`@/img/${iconName}`);
    }
  }
};
</script>


<style  lang="less" scoped>
.dsad:hover {
  display: block;
}

.type-nav {
  border-bottom: 2px solid;
  width: 80%;
  margin: 0 auto;

  .container {
    margin: 0 auto;
    display: flex;
    position: relative;
    height: 545px;

    .sort {
      position: absolute;
      left: 0;
      top: 0px;
      width: 256px;
      height: 545px;
      background: #fafafa;
      z-index: 999;

      .all-sort-list2 {
        .item:hover {
          background-color: skyblue;
        }

        .item {
          h3 {
            display: flex;
            /* 使用 flexbox 实现图标和文字并排 */
            align-items: center;
            /* 垂直居中对齐 */
            font-size: 14px;
            font-weight: 400;
            overflow: hidden;
            margin: 0;

            a {
              color: #333;
              margin-left: 10px; /* 给文本加点间距 */
            }
          }

          .item-list {
            display: none;
            position: absolute;
            min-height: 300px;
            _height: 200px;
            background: #f7f7f7;
            left: 250px;
            border: 1px solid #ddd;
            top: 0;
            z-index: 9999 !important;

            .subitem {
              float: left;
              width: 450px;
              padding: 0 4px 0 8px;

              dl {
                border-top: 1px solid #eee;
                padding: 6px 0;
                overflow: hidden;
                zoom: 1;

                &.fore {
                  border-top: 0;
                }

                dt {
                  float: left;
                  width: 80px;
                  line-height: 22px;
                  text-align: right;
                  padding: 3px 6px 0 0;
                  font-weight: 700;
                }

                dd {
                  float: left;
                  width: 415px;
                  padding: 3px 0 0;
                  overflow: hidden;

                  em {
                    float: left;
                    height: 14px;
                    line-height: 14px;
                    padding: 0 8px;
                    margin-top: 5px;
                    border-left: 1px solid #ccc;

                    a {
                      color: #333333;
                    }
                  }
                }
              }
            }
          }

          &:hover {
            .item-list {
              display: block;
            }
          }
        }
      }
    }
  }
}</style>