for (var i = 0; i < 3; i++) {
    setTimeout(function() {
      console.log(i);  // 输出 3, 3, 3
    }, 1000);
  }
//在这段代码中，i 是通过 var 声明的。var 声明的变量是函数作用域的，
// 意味着整个 for 循环都共享同一个 i 变量。而 setTimeout 是异步执行的，
// 它并不会在每次循环时记录当前的 i 值，而是直接引用 i。
// 因此，当 setTimeout 的回调函数真正执行时，for 循环已经执行完毕，i 的最终值是 3（因为循环结束时 i 的值是 3）。
  
for (let i = 0; i < 3; i++) {
   setTimeout(function() {
     console.log(i);  // 输出 0, 1, 2
    }, 1000);
}
// let 是块级作用域的，每次循环迭代都会创建一个新的 i 变量。因此，当回调函数被执行时，它会访问当前的 i 值，而不是最终的 i 值。

// 执行栈 （用var）: i=1  console.log(i); i=2 console.log(i); i=3 console.log(i);   
//但是console是异步，因此等for循环完后才执行，console依旧还是排队在执行栈里的
//此时，var和let的差别就体现出来了
// 执行栈 （用let）: i=1  console.log(i); i=2 console.log(i); i=3 console.log(i); 


const counterModule = (function() {
    let count = 0;  // 私有变量
    return {
      increment: function() {
        count++;
        console.log(count);
      },
      decrement: function() {
        count--;
        console.log(count);
      },
      getCount: function() {
        return count;
      }
    }
  })();
  
  counterModule.increment();  // 1
  counterModule.decrement();  // 0
  console.log(counterModule.getCount());  // 0


//   遍历（forEach，every，some，for..of，for..in）
// JavaScript 提供了多种遍历数组和对象的方法：

// forEach()：遍历数组的每个元素，执行回调函数。不会返回任何值。
[1, 2, 3].forEach(item => console.log(item)); // 1, 2, 3

// every()：检查数组中的每个元素是否满足指定条件，返回布尔值。
const isEven = [2, 4, 6].every(num => num % 2 === 0); // true

// some()：检查数组中是否有任意元素满足指定条件，返回布尔值。
const hasEven = [1, 2, 3].some(num => num % 2 === 0); // true

// for..of：用于遍历数组或其他可迭代对象（如字符串、Set、Map）。
for (let num of [1, 2, 3]) {
  console.log(num); // 1, 2, 3
}

// for..in：用于遍历对象的可枚举属性。
const obj = { name: 'Alice', age: 25 };
for (let key in obj) {
  console.log(key, obj[key]); // name Alice, age 25
}


typeof "Hello"    // "string"
typeof 42         // "number"
typeof true       // "boolean"
typeof undefined  // "undefined"
typeof null       // "object" (历史遗留问题)
typeof {}         // "object"
typeof []         // "object"
typeof function(){} // "function"



// - Object()
// 用于创建一个新的对象。可以用它来创建空对象或转换其他类型为对象。
let objs = new Object(); // 创建一个空对象

// - Function()
// 用于动态创建函数，接受一组字符串形式的参数，生成对应的函数体。
let add = new Function('a', 'b', 'return a + b');
console.log(add(2, 3)); // 5

// - RegExp()
// 用于创建正则表达式对象。可以通过字符串模式和标志来创建正则。
let regex = new RegExp('\\d+', 'g');
console.log(regex.test("123")); // true

// - Date()
// 用于创建日期对象，获取当前日期和时间。
let date = new Date();
console.log(date.toString()); // 当前日期和时间

// - Error()
// 用于创建自定义错误对象。
let err = new Error('Something went wrong');
console.log(err.message); // 'Something went wrong'

// - Symbol()
// 用于创建独一无二的符号值，通常用作对象的键。Symbol 是一种新的原始数据类型，具有唯一性。
let sym = Symbol('description');
console.log(sym); // Symbol(description)



console.log('Start');
function foo() {
  console.log("Inside foo");
} 
function bar() {
  foo();
  console.log("Inside bar");
} 
setTimeout(() => {
  console.log('Timeout');
}, 0);

Promise.resolve().then(() => {
  console.log('Promise');
});
bar();


console.log('End');