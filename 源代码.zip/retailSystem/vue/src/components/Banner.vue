<template>
  <el-carousel :interval="3000" class="bg">
    <el-carousel-item v-for="(item, index) in imgs" :key="index" class="banner">
      <!-- 使用相对路径加载图片 -->
      <img :src="getImageUrl(item.imgUrl)" style="width: 100%; height: 100%">
    </el-carousel-item>
  </el-carousel>
</template>

<script>
import axios from "axios";
import { baseURL } from "../../public/urlConfig";

export default {
  name: "Banner",
  data() {
    return {
      imgs: [] // 初始化为一个数组，而不是对象
    };
  },
  created() {
    this.load();
  },
  methods: {
    load() {
      axios.get(baseURL + '/index-img/img').then(
        res => {
          this.imgs = res.data.data; // 这里假设接口返回的 imgs 是一个数组
        }
      );
    },
    // 通过 require 动态加载图片
    getImageUrl(imageName) {
      return require(`@/img/${imageName}`); // 返回相对路径
    }
  }
};
</script>


<style scoped>
.bg{
  height: 540px;
}
.banner{
  height: 530px;
}
/*.list-container {
  margin: 0 auto;

  .sortList {
    height: 350px;
    padding-left: 210px;

    .center {
      box-sizing: border-box;
      width: 740px;
      height: 100%;
      padding: 5px;
      float: left;
    }
  }
}*/
</style>