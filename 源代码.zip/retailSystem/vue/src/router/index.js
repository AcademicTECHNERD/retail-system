import Vue from 'vue'
import VueRouter from 'vue-router'
import Login from "@/views/Login";
import Index from "@/views/Index";
import Product from "@/views/Product";
import ShopCart from "@/views/ShopCart";
import Order from "../views/Order";
import PaySuccess from "../views/PaySuccess";
import SearchProduct from "../views/SearchProduct";
import SearchList from "../views/SearchList";
import orderList from "../views/OrderList";
import orderDetail from "../views/OrderDetail";
import Remark from "../views/Remark";
import Search from "../views/Search";
import history from "../views/History";
import Pay from "../views/Pay";
import AddProduct from "../views/AddProduct";
import ArticleDetail from "../views/article/ArticleDetail";   //文章详情页
import ArticleHome from "../views/ArticleHome";               //帖子主页

import HomeView from "../views/HomeView";                     //智慧搜索主页
import NotFound from "../views/NotFound";
import MerchantHome from "../views/Merchant/MerchantHome";   //商家后台主页

import AI_model from '../views/tools/AI_model.vue';       //AI模型
import BrandHistory from "../views/tools/brandHistory";  //品牌历史
import cashbook from "../views/tools/cashbook";         //记账本
//获取原型对象上的push函数
/*const originalPush = VueRouter.prototype.push
//修改原型对象中的push方法
VueRouter.prototype.push = function push(location) {
  return originalPush.call(this, location).catch(err => err)
}*/
Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'Home',
    component: Index
  },
    //独立路由，非子路由
  
  {
    path: '/HomeView',
    name: 'HomeView',
    component: HomeView
  },
  {
    path: '/ArticleHome',
    name: 'ArticleHome',
    component: ArticleHome
  },
  {
    path: '/article/:id',
    name: 'ArticleDetail',
    component: ArticleDetail
  },
  {
    path: '/cashbook',
    name: 'cashbook',
    component: cashbook
  },
  {
    path: '/login',
    name:'Login',
    component:Login
  },
  {
    path: '/register',
    name: 'Register',
    component: () => import('../views/Register.vue')  //路由懒加载
  },
  {
    path: '/person',
    name: 'FrontPerson',
    component: () => import('../views/Person.vue')
  },
  {
    path: '/product',
    name: 'Product',
    component: Product
  },
  {
    path: '/product/:id',  // 使用商品ID作为路由参数
    name: 'SearchProduct',
    component: SearchProduct,
    props: true,  // 将路由参数作为 props 传递给组件
  },
  {
    path: '/searchList',
    name: 'SearchList',
    component: SearchList
  },
  {
    path: '/shopcart',
    name: 'ShopCart',
    component: ShopCart
  },
  {
    path: '/order',
    name: 'Order',
    component: Order
  },
  {
    path: '/paySuccess',
    name:'PaySuccess',
    component: PaySuccess
  },
  {
    path: '/orderList',
    name: 'orderList',
    component: orderList
  },
  {
    path: '/orderDetail',
    name: 'orderDetail',
    component: orderDetail
  },
  {
    path: '/remark',
    name: 'Remark',
    component: Remark
  },
  {
    path: '/search',
    name: 'Search',
    component: Search
  },
  {
    path:'/history',
    name:'History',
    component: history
  },
  {
    path: '/pay',
    name:'Pay',
    component: Pay
  },
  {
    path: '/addProduct',
    name:'AddProduct',
    component: AddProduct
  },
  {
    path: '/merchantHome',
    name: 'MerchantHome',
    component: MerchantHome
  },
  {
    path: '/AI_model',
    name: 'AI_model',
    component: AI_model
  },
  {
    path: '/BrandHistory',
    name: 'BrandHistory',
    component: BrandHistory
  },
  {
    path: '/:catchAll(.*)', // 捕获所有路径
    name: 'NotFound', // 确保这里的 name 和你跳转时使用的名字一致
    component: NotFound
  }
  
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})
export default router
