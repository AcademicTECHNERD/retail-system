<template>
    <div style="overflow-x: hidden">
        <Navi />
        <el-row :gutter="20" style="background-color: white;width: 80%;margin: 0 auto">
            <el-col :span="8">
                <el-col>
                    <el-image v-if="productImgs && productImgs.length > 0"
                        :src="getImageUrl(productImgs[currentImgIndex]?.url)" fit="fill"
                        :preview-src-list="[getImageUrl(productImgs[currentImgIndex]?.url)]" style="height: 210px">
                    </el-image>
                </el-col>
                <el-col>
                    <el-carousel :autoplay="false" type="card" height="100px" @change="changeImg">
                        <el-carousel-item v-for="(item, index) in productImgs" :key="index">
                            <el-image :src="getImageUrl(item.url)" style="height: 100%;"></el-image>
                        </el-carousel-item>
                    </el-carousel>
                </el-col>
            </el-col>
            <el-col :span="16">
                <el-col>
                    <h3 style="float: left; margin: 5px;">{{ productInfo.productName }}</h3>
                </el-col>

                <!-- 商品价格 -->
                <el-col style="background-color: #fee9eb;" v-if="productSku.length > 0">
                    <!-- 原价 -->
                    <el-col style="margin: 5px;">
                        <el-col :span="3" style="text-align: left; font-size: 16px;">原价：</el-col>
                        <el-col :span="16" style="text-align: left;">
                            <em style="font-size: 16px; text-decoration: line-through;">¥{{
                                productSku[currentSkuIndex].originalPrice }}</em>
                        </el-col>
                    </el-col>

                    <!-- 促销价 -->
                    <el-col style="margin: 5px;">
                        <el-col :span="3" style="text-align: left; font-size: 16px;">促销价：</el-col>
                        <el-col :span="16" style="text-align: left; color: #c81623;">
                            <em style="font-size: 30px; font-weight: 700;">¥{{ productSku[currentSkuIndex].sellPrice }}</em>
                        </el-col>
                    </el-col>
                </el-col>

                <!-- 商品规格（套餐） -->
                <el-col>
                    <span style="margin: 5px; float: left;">套餐：</span>
                    <div style="margin: 5px; float: left" v-for="(sku, index) in productSku" :key="sku.skuId">
                        <el-radio-group v-model="currentSkuIndex" size="medium" @change="changeSku">
                            <el-radio-button :label="index">{{ sku.skuName }}</el-radio-button>
                        </el-radio-group>
                    </div>
                </el-col>

                <!-- 商品属性 -->
                <el-col v-for="(value, key, index) in skuProps" :key="index">
                    <span style="margin: 5px; float: left">{{ key }}：</span>
                    <div style="margin: 5px; float: left" v-for="(sku) in value" :key="sku">
                        <el-radio-group v-model="tab[index].value" :key="key" size="medium"
                            @change="(skus) => changeKey(skus, key)">
                            <el-radio-button :label="sku">{{ sku }}</el-radio-button>
                        </el-radio-group>
                    </div>
                </el-col>

                <!-- 商品库存、销量 -->
                <el-col>
                    <el-descriptions size="medium" style="text-align: left; font-size: 16px; margin: 5px;">
                        <el-descriptions-item label="库存：">{{ productSku[currentSkuIndex].stock }}</el-descriptions-item>
                        <el-descriptions-item label="累计销量：">{{ productInfo.soldNum }}件</el-descriptions-item>
                    </el-descriptions>
                </el-col>

                <!-- 数量选择和按钮 -->
                <el-col>
                    <el-input-number v-model="num" :min="1" :max="productSku[currentSkuIndex].stock" label="描述文字"
                        style="float: left; margin: 5px"></el-input-number>
                    <el-button type="warning" round plain style="margin: 5px;" @click="addList">添加购物车</el-button>
                    <el-button type="success" round plain style="margin: 5px;" @click="submit">立即购买</el-button>
                </el-col>
            </el-col>
        </el-row>
        <!-- 商品详情、评论、图片等 -->
        <el-tabs type="border-card" style="margin: 0 auto;width: 80%">
            <el-tab-pane label="宝贝详情">
                <ProductParams :productId="productId"></ProductParams>
            </el-tab-pane>
            <el-tab-pane>
                <span slot="label"><i class="el-icon-chat-dot-square"></i> 评价</span>
                <Comments :productId="productId"></Comments>
            </el-tab-pane>
            <el-image :src="getImageUrl(productImgs[currentImgIndex]?.url)" fit="fill"
                :preview-src-list="[getImageUrl(productImgs[currentImgIndex]?.url)]" style="height: 100%"></el-image>
        </el-tabs>
    </div>
</template>

<script>
import axios from "axios";
import { baseURL } from "../../public/urlConfig";
import router from "@/router";
import Navi from "../components/Navi";
import ProductParams from "../components/ProductParams";
import Comments from "../components/Comments";

let skuMaps = new Map();

export default {
    name: "SearchProduct",
    components: { ProductParams, Navi, Comments },
    data() {
        return {
            productId: "",
            num: 1,
            currentSkuIndex: 0,
            currentImgIndex: 0,
            tab: [],
            productInfo: {},
            productSku: [],
            productImgs: [],
            skuProps: {},
        };
    },
    created() {
        // 获取商品ID
        if (this.$route.query.id) {
            this.productId = this.$route.query.id;
        }
        this.loadProductDetails();
        for (let i = 0; i < 3; i++) {
            this.tab.push({ value: "0" });
        }
    },
    methods: {
        loadProductDetails() {
            axios.get(`${baseURL}/products/product/${this.productId}`).then(res => {
                this.productInfo = res.data.data.product;
                this.productSku = res.data.data.productSku;
                this.productImgs = res.data.data.productImgs;
                this.skuProps = res.data.data.productSkuProps; // SKU 属性
            }).catch(error => {
                console.error('加载商品详情失败:', error);
                this.$message.error('加载商品详情失败，请稍后再试');
            });
        },
        changeSku(value) {
            this.currentSkuIndex = value;
            this.skuProps = eval(`(${this.productSku[this.currentSkuIndex].untitled})`); // 更新 SKU 属性
        },
        changeImg(val) {
            if (val >= 0 && val < this.productImgs.length) {
                this.currentImgIndex = val;
            } else {
                this.currentImgIndex = 0; // 防止超出范围
            }
        },
        changeKey(val, key) {
            skuMaps.set(key, val);
        },
        addList() {
            let skuProps = "";
            for (let keys of skuMaps.keys()) {
                skuProps += keys + ":" + skuMaps.get(keys) + ";";
            }
            const cartItem = {
                cartNum: this.num,
                productId: this.productId,
                productPrice: this.productSku[this.currentSkuIndex].sellPrice,
                skuId: this.productSku[this.currentSkuIndex].skuId,
                skuProps: skuProps,
                userId: localStorage.getItem("userId"),
            };
            const token = localStorage.getItem("token");
            axios.post(`${baseURL}/shopping-cart/add`, cartItem, {
                headers: { token }
            }).then(res => {
                if (res.data.code == 10000) {
                    this.$message.success(res.data.msg);
                } else {
                    this.$message.error(res.data.msg);
                }
            });
        },
        submit() {
            let skuProps = "";
            for (let keys of skuMaps.keys()) {
                skuProps += keys + ":" + skuMaps.get(keys) + ";";
            }
            const cartItem = {
                cartNum: this.num,
                productId: this.productId,
                productPrice: this.productSku[this.currentSkuIndex].sellPrice,
                skuId: this.productSku[this.currentSkuIndex].skuId,
                skuProps: skuProps,
                userId: localStorage.getItem("userId"),
            };
            const token = localStorage.getItem("token");
            axios.post(`${baseURL}/shopping-cart/add`, cartItem, {
                headers: { token }
            }).then(res => {
                if (res.data.code == 10000) {
                    this.$router.push(`/order?cids=${res.data.data}`);
                } else {
                    this.$message.error(res.data.msg);
                }
            });
        },
        // 返回图片的相对路径
        getImageUrl(imageName) {
            return require(`@/img/${imageName}`);
        },
    }
};
</script>
