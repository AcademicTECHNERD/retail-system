<template>
  <div class="app">
    <!-- 左侧侧边栏 -->
    <div :class="['sidebar', { 'sidebar-open': sidebarOpen, 'sidebar-closed': !sidebarOpen }]">
      <div class="sidebar-header">
        <button class="sidebar-btn" @click="ToHomeView">智慧搜索主页</button>
        <button class="sidebar-btn" @click="ToShopping">商城首页</button>
        <button class="sidebar-btn" @click="ToMy">我是创作者</button>
      </div>
      <!-- <div class="sidebar-toggle" @click="toggleSidebar">
        <span>{{ sidebarOpen ? '←' : '→' }}</span>
      </div> -->
    </div>

    <!-- 右侧内容区域 -->
    <div :class="['main-content', { 'main-content-shifted': !sidebarOpen }]">
      <header class="navbar">
        <div class="logo">📕</div>
        <input type="text" placeholder="搜索内容、话题" class="search-bar" />
        <div class="icons">
          <span class="notification-icon">🔔</span>
          <span class="profile-icon">👤</span>
        </div>
      </header>

      <!-- 帖子流 -->
      <main class="post-feed">
        <div v-for="post in posts" :key="post.id" class="post">
          <div class="post-content">
            <!-- 动态加载封面图片 -->
            <img :src="getPostImage(post.coverImg)" alt="Cover Image" class="post-image" />

            <h3 class="post-title" @click="goToDetail(post.id)">{{ post.title }}</h3>
            <p class="post-tags">{{ post.tags.join(', ') }}</p>
            <div class="post-user">
              <span class="user-name">{{ post.user.name }}</span>
            </div>
          </div>
        </div>
      </main>
    </div>
  </div>
</template>


<script>
import axios from 'axios';

export default {
  name: "ArticleHome",
  data() {
    return {
      posts: [],
      sidebarOpen: true, // 控制侧边栏展开或收起
    };
  },
  mounted() {
    this.fetchPosts();
  },
  methods: {
    async fetchPosts() {
      try {
        const response = await axios.get('http://localhost:9090/retaildemo/article/all');
        this.posts = response.data.map(post => {
          const tags = post.categoryName ? [post.categoryName] : ['暂无标签'];
          return {
            id: post.id,
            title: post.title || '未命名文章',
            tags: tags,
            user: {
              name: post.username || '未知用户',
            },
            coverImg: post.coverImg || 'default.jpg', // 处理封面图为空的情况
          };
        });
      } catch (error) {
        console.error('获取文章列表失败:', error);
      }
    },
    // 判断是否有封面图，没有则使用默认图片
    getPostImage(coverImg) {
      try {
        // 使用 Webpack 动态导入图片
        return require(`@/img/ArticleImg/${coverImg}`);
      } catch (e) {
        // 捕获错误并返回默认图片
        return require('@/img/ArticleImg/default.jpg');
      }
    }
    ,
    ToHomeView() {
      this.$router.push('/HomeView');
    },
    ToShopping() {
      this.$router.push('/');
    },
    ToMy() {
      this.$router.push('/Person');
    },
    goToDetail(id) {
      this.$router.push({ name: 'ArticleDetail', params: { id } });
    },
    toggleSidebar() {
      this.sidebarOpen = !this.sidebarOpen; // 切换侧边栏展开或收起
    }
  },
};
</script>



<style scoped>
/* 页面总体样式 */
.app {
  display: flex;
  height: 100vh;
  background-color: #f7f7f7;
  font-family: Arial, sans-serif;
  transition: margin-left 0.3s ease;
}

/* 左边栏样式 */
.sidebar {
  width: 250px;
  color: #fff;
  transition: width 0.3s ease, box-shadow 0.3s ease;
  padding-top: 20px;
  position: relative;
  display: flex;
  flex-direction: column;
}

.sidebar-open {
  width: 150px;
  /* 左边栏展开 */
}

.sidebar-closed {
  width: 50px;
  /* 左边栏收缩 */
}

/* 左边栏内容 */
.sidebar-header {
  display: flex;
  flex-direction: column;
  width: 100%;
}

.sidebar-btn {
  background-color: #f7f7f7;
  /* color: #fff; */
  color: black;
  border: none;
  padding: 12px;
  text-align: center;
  width: 100%;
  margin: 5px 0;
  cursor: pointer;
  /* border-radius: 20px; */
  transition: 0.3s;
  flex: 1;
}

.sidebar-btn:hover {
  background-color: rgba(161, 90, 90, 0.566);
  box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.2);
}

/* 收缩/展开控制尾巴部分 */
.sidebar-toggle {
  position: absolute;
  top: 90%;
  right: -30px;
  cursor: pointer;
  font-size: 24px;
  color: #fff;
  background-color: #333;
  width: 50px;
  height: 50px;
  display: flex;
  justify-content: center;
  align-items: center;
  box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.2);
  transform: translateY(-50%);
}

.sidebar-toggle:hover {
  background-color: red;
}

/* 右侧内容区域 */
.main-content {
  flex: 1;
  display: flex;
  flex-direction: column;
  transition: margin-left 0.3s ease;
}

/* 右侧内容区域偏移 */
.main-content-shifted {
  margin-left: 50px;
  /* 右侧内容区域向左偏移 */
}

/* 顶部导航栏 */
.navbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px;
  background-color: #ffffff;
  box-shadow: 0px 1px 5px rgba(0, 0, 0, 0.1);
}

.logo {
  font-size: 24px;
}

.search-bar {
  flex: 1;
  margin: 0 10px;
  padding: 5px 10px;
  border-radius: 15px;
  border: 1px solid #ddd;
}

.icons {
  display: flex;
  gap: 10px;
}

/* 帖子流样式 */
.post-feed {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  /* 每个卡片宽度最小300px */
  gap: 20px;
  padding: 10px;
  overflow-y: auto;
}

/* 调整每个帖子的盒子样式 */
.post {
  background-color: #ffffff;
  border-radius: 10px;
  box-shadow: 0px 1px 3px rgba(0, 0, 0, 0.1);
  overflow: hidden;
  transition: transform 0.3s ease;
  display: flex;
  flex-direction: column;
  /* 纵向布局 */
  height: 0;
  padding-top: 66.67%;
  position: relative;
}

/* 鼠标悬停时放大 */
.post:hover {
  transform: scale(1.02);
}

/* 图片样式，确保占用盒子上部的三分之二并拉伸 */
.post-image {
  width: 100px;
  height: 150px;
  /* 占三分之二的高度 */
  object-fit: cover;
  border-radius: 10px 10px 0 0;
  position: absolute;
  top: -150px;
  right: 116px;
}

/* 内容区域样式，剩余的三分之一空间 */
.post-content {
  position: absolute;
  bottom: 0;
  width: 100%;
  padding: 10px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  height: 33.33%;
  /* 占三分之一的高度 */
  background-color: #fff;
  text-align: center;
  border-radius: 0 0 10px 10px;
  /* 仅下部分圆角 */
}

/* 标题样式 */
.post-title {
  font-size: 16px;
  font-weight: bold;
  margin: 5px 0;
}

/* 标签样式 */
.post-tags {
  font-size: 12px;
  color: #888;
  margin: -5px 0;
}

/* 用户信息样式 */
.post-user {
  display: flex;
  align-items: center;
  justify-content: center;
  margin-top: 5px;
}

.user-name {
  font-size: 14px;
  color: #333;
}</style>
