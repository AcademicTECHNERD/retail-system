<template>
  <div>
    <Navi></Navi>
    <div>
      <el-row style="width: 80%;margin: 0 auto">
        <el-col :span="12" style="margin-top: 5px;margin-bottom: 5px">
          <el-link href="/" style="float: left" :underline="false">
            <img src="../assets/logo.png" width="130px" />
          </el-link>
        </el-col>
        <el-col :span="12" style="margin-top: 10px;margin-bottom: 5px">
          <div style="margin-top: 15px;">
            <el-input placeholder="请输入内容" v-model="input">
              <el-button slot="append" icon="el-icon-search" style="background-color: #FF5A00;color: white"
                @click="fuzzyQuery">搜索</el-button>
            </el-input>
          </div>
        </el-col>
      </el-row>
    </div>
    <el-row style="width: 80%;margin: 0 auto;padding: 10px">
      <el-col :span="6">
        <Category></Category>
      </el-col>
      <el-col :span="16">
        <Banner></Banner>
      </el-col>
    </el-row>
    <Recommend></Recommend>
  </div>
</template>
<script>
import Category from "@/components/Category";
import Banner from "@/components/Banner";
import Recommend from "@/components/Recommend";
import CategoryRecommend from "@/components/CategoryRecommend";
import Navi from "../components/Navi";
import axios from "axios";
// import { baseURL } from "../../public/urlConfig"; // 确保你的urlConfig是正确的

export default {
  name: "Index",
  components: {
    Navi,
    Category,
    Banner,
    Recommend,
    CategoryRecommend
  },
  data() {
    return {
      input: "", // 用户输入的搜索内容
      searchResults: [] // 存储搜索结果
    };
  },
  methods: {
    // 搜索方法
    fuzzyQuery() {
      if (this.input.trim() !== "") {
        // 确保传递的请求体是纯文本而不是 JSON
        axios.post("http://localhost:9090/api/retaildemo/products/search", this.input, {
          headers: {
            'Content-Type': 'text/plain', // 设置请求头为纯文本
          }
        })
          .then((response) => {
            console.log(response.data);
            console.log("输入的关键字：" + this.input);
            if (response.data.code === 200) {
              // 如果有搜索结果，跳转到 searchlist 页面并传递搜索结果
              this.$router.push({
                name: "SearchList",
                query: { products: JSON.stringify(response.data.data) },
              });
            } else {
              this.$message.warning("没有找到相关商品");
            }
          })
          .catch((error) => {
            console.error("搜索失败:", error);
            this.$message.error("搜索请求失败，请稍后重试");
          });
      } else {
        this.$message.warning("请输入搜索内容");
      }
    }

  }
};
</script>

<style scoped></style>