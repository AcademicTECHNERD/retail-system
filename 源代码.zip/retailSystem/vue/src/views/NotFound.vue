<template>
    <div class="not-found">
        <!-- 星空背景 -->
        <div class="stars">
            <div v-for="star in 100" :key="star" class="star" :style="generateStarStyle()"></div>
        </div>

        <!-- 主文案 -->
        <div class="text">
            <h1>404</h1>
            <p>Oops! The page you are looking for is lost in space...</p>
        </div>

        <!-- 动画飞船 -->
        <img class="spaceship" src="/spaceship.png" alt="Spaceship" />
    </div>
</template>
  
<script>
import { defineComponent } from "vue";

export default defineComponent({
    name: "NotFound",
    methods: {
        generateStarStyle() {
            return {
                top: `${Math.random() * 100}vh`,
                left: `${Math.random() * 100}vw`,
                animationDelay: `${Math.random() * 2}s`,
            };
        },
    },
});
</script>
  
<style scoped>
/* 整体样式 */
.not-found {
    background: radial-gradient(ellipse at center, #0b0d1e, #000);
    color: #fff;
    overflow: hidden;
    height: 100vh;
    position: relative;
    font-family: Arial, sans-serif;
}

/* 星星动画 */
.stars {
    position: absolute;
    width: 100%;
    height: 100%;
}

.star {
    position: absolute;
    width: 2px;
    height: 2px;
    background: white;
    border-radius: 50%;
    animation: blink 2s infinite;
}

@keyframes blink {
    50% {
        opacity: 0.5;
    }
}

/* 文案 */
.text {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    text-align: center;
}

.text h1 {
    font-size: 6rem;
    color: #ff6f61;
    text-shadow: 0 0 10px #ff6f61, 0 0 20px #ff0000;
    animation: float 3s infinite;
}

.text p {
    font-size: 1.5rem;
    color: #ddd;
}

@keyframes float {

    0%,
    100% {
        transform: translateY(-10px);
    }

    50% {
        transform: translateY(10px);
    }
}

/* 飞船动画 */
.spaceship {
    position: absolute;
    width: 100px;
    animation: fly 6s infinite linear;
}

@keyframes fly {
    0% {
        transform: translate(-10%, -10%);
    }

    100% {
        transform: translate(120%, 120%);
    }
}
</style>
  