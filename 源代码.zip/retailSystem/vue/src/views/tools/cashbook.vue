<template>
    <div class="budget-app">
        <!-- 标题 -->
        <header class="header">
            <h1>记账本</h1>
            <p>记录你的每一笔收入和支出，管理你的财务。</p>
        </header>

        <!-- 添加记录表单 -->
        <div class="add-transaction">
            <h2>添加记录</h2>
            <form @submit.prevent="addTransaction">
                <label>
                    类别:
                    <select v-model="newTransaction.type" required>
                        <option value="income">收入</option>
                        <option value="expense">支出</option>
                    </select>
                </label>
                <label>
                    金额:
                    <input type="number" v-model.number="newTransaction.amount" placeholder="输入金额" required />
                </label>
                <label>
                    备注:
                    <input type="text" v-model="newTransaction.note" placeholder="备注（可选）" />
                </label>
                <button type="submit">添加</button>
            </form>
        </div>

        <!-- 总览 -->
        <div class="overview">
            <div class="summary">
                <h3>总收入</h3>
                <p class="income">{{ calculateTotal('income') }} 元</p>
            </div>
            <div class="summary">
                <h3>总支出</h3>
                <p class="expense">{{ calculateTotal('expense') }} 元</p>
            </div>
            <div class="summary">
                <h3>余额</h3>
                <p :class="{ positive: balance >= 0, negative: balance < 0 }">{{ balance }} 元</p>
            </div>
        </div>

        <!-- 记录列表 -->
        <div class="transaction-list">
            <h2>记录列表</h2>
            <ul>
                <li v-for="(transaction, index) in transactions" :key="index">
                    <span class="type" :class="transaction.type">{{ transaction.type === 'income' ? '收入' : '支出' }}</span>
                    <span class="amount">{{ transaction.amount }} 元</span>
                    <span class="note">{{ transaction.note }}</span>
                    <button @click="deleteTransaction(index)">删除</button>
                </li>
            </ul>
        </div>
    </div>
</template>
  
<script>
import axios from 'axios';
export default {
    name: "cashbook",
    data() {
        return {
            transactions: [], // 记录所有交易
            newTransaction: {
                type: "income", // 新交易的类型
                amount: null, // 新交易的金额
                note: "", // 新交易的备注
            },
        };
    },
    computed: {
        balance() {
            const income = this.calculateTotal("income");
            const expense = this.calculateTotal("expense");
            return income - expense; // 计算余额
        },
    },
    methods: {
        addTransaction() {
            if (this.newTransaction.amount <= 0) {
                alert("金额必须大于 0！");
                return;
            }

            this.transactions.push({
                type: this.newTransaction.type,
                amount: this.newTransaction.amount,
                note: this.newTransaction.note || "无备注",
            });

            // 清空输入框
            this.newTransaction = { type: "income", amount: null, note: "" };
        },
        deleteTransaction(index) {
            this.transactions.splice(index, 1);
        },
        calculateTotal(type) {
            return this.transactions
                .filter((t) => t.type === type)
                .reduce((sum, t) => sum + t.amount, 0);
        },
    },
};
</script>
  
<style scoped>
/* 全局样式 */
body {
    font-family: Arial, sans-serif;
    background: #f5f5f5;
    margin: 0;
    padding: 0;
}

/* 容器 */
.budget-app {
    max-width: 800px;
    margin: 30px auto;
    background: #fff;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

/* 标题样式 */
.header {
    text-align: center;
    margin-bottom: 20px;
}

.header h1 {
    font-size: 2rem;
    color: #333;
}

.header p {
    color: #666;
}

/* 添加记录表单 */
.add-transaction {
    margin-bottom: 30px;
}

.add-transaction h2 {
    margin-bottom: 10px;
    font-size: 1.5rem;
}

.add-transaction form {
    display: flex;
    gap: 15px;
    flex-wrap: wrap;
    align-items: center;
}

.add-transaction label {
    display: flex;
    flex-direction: column;
    font-size: 0.9rem;
    color: #333;
}

.add-transaction input,
.add-transaction select {
    padding: 5px;
    font-size: 1rem;
    border: 1px solid #ccc;
    border-radius: 5px;
    margin-top: 5px;
}

.add-transaction button {
    background: #007bff;
    color: #fff;
    padding: 10px 15px;
    font-size: 1rem;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

.add-transaction button:hover {
    background: #0056b3;
}

/* 总览 */
.overview {
    display: flex;
    justify-content: space-between;
    margin-bottom: 30px;
}

.summary {
    text-align: center;
    flex: 1;
}

.summary h3 {
    margin-bottom: 10px;
    color: #333;
}

.summary p {
    font-size: 1.2rem;
    font-weight: bold;
}

.income {
    color: #28a745;
}

.expense {
    color: #dc3545;
}

.positive {
    color: #28a745;
}

.negative {
    color: #dc3545;
}

/* 记录列表 */
.transaction-list ul {
    list-style: none;
    padding: 0;
}

.transaction-list li {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px 15px;
    border-bottom: 1px solid #f0f0f0;
}

.transaction-list .type {
    font-weight: bold;
}

.transaction-list .type.income {
    color: #28a745;
}

.transaction-list .type.expense {
    color: #dc3545;
}

.transaction-list button {
    background: #dc3545;
    color: #fff;
    border: none;
    padding: 5px 10px;
    border-radius: 5px;
    cursor: pointer;
}

.transaction-list button:hover {
    background: #c82333;
}
</style>
  