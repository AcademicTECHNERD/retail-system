<template>
    <div class="brand-history">
      <!-- <h1>品牌历史</h1> -->
      <!-- 加载中状态 -->
      <div v-if="loading" class="loading">加载中...</div>
      <!-- 错误信息 -->
      <div v-else-if="error" class="error">{{ error }}</div>
      <!-- 渲染 Markdown 转换后的 HTML -->
      <div v-else class="content" v-html="htmlContent"></div>
    </div>
  </template>
  
  <script>
  import axios from 'axios';
 import { marked } from 'marked'
  
  export default {
    name: 'BrandHistory',
    data() {
      return {
        markdownContent: '', // 存储原始 Markdown 内容
        htmlContent: '',     // 存储转换后的 HTML 内容
        loading: true,
        error: null
      };
    },
    mounted() {
      // 从 public 文件夹中加载 brandHistory.md 文件
      axios
        .get('/brandHistory.md')
        .then((response) => {
          this.markdownContent = response.data;
          this.htmlContent = marked(this.markdownContent);
        })
        .catch((err) => {
          console.error(err);
          this.error = '加载品牌历史内容失败：' + err.message;
        })
        .finally(() => {
          this.loading = false;
        });
    }
  };
  </script>
  
  <style scoped>
  .brand-history {
    padding: 20px;
    max-width: 800px;
    margin: 0 auto;
    font-family: Arial, sans-serif;
  }
  
  .loading {
    text-align: center;
    font-size: 16px;
    padding: 20px;
  }
  
  .error {
    color: red;
    text-align: center;
    margin-top: 20px;
  }
  
  .content {
    line-height: 1.6;
  }
  
 
  </style>
  