<template>
  <div class="ai-model-container">
    <div class="chat-container">
      <div class="messages" ref="messagesContainer">
        <div v-for="(message, index) in messages" :key="index" class="message"
          :class="{ 'user-message': message.isUser, 'ai-message': !message.isUser }">
          <div class="message-content">{{ message.text }}</div>
        </div>
        <div v-if="isLoading" class="loading-indicator">
          正在思考中...
        </div>
      </div>
    </div>

    <div class="input-container">
      <el-input v-model="userInput" placeholder="输入你的问题..." @keyup.enter="sendMessage" clearable class="input-box" />
      <el-button type="primary" @click="sendMessage" :disabled="isLoading" class="send-btn">
        {{ isLoading ? '生成中...' : '发送' }}
      </el-button>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      userInput: '',
      messages: [],
      isLoading: false
    };
  },
  methods: {
    async sendMessage() {
      if (!this.userInput.trim() || this.isLoading) return;

      this.messages.push({ text: this.userInput, isUser: true });
      const question = this.userInput;
      this.userInput = '';
      this.scrollToBottom();

      this.isLoading = true;
      try {
        const response = await axios.post('http://localhost:3001/api/chat', {
          messages: [{ role: "user", content: question }],
          parameters: {
            temperature: 0.5,
            max_tokens: 2048
          }
        });

        this.messages.push({
          text: response.data.choices[0].message.content,
          isUser: false
        });
      } catch (error) {
        this.showError(error.message);
      } finally {
        this.isLoading = false;
        this.scrollToBottom();
      }
    },
    scrollToBottom() {
      this.$nextTick(() => {
        const container = this.$refs.messagesContainer;
        container.scrollTop = container.scrollHeight;
      });
    },
    showError(msg) {
      this.$message({
        message: msg || '请求发生错误',
        type: 'error',
        duration: 5000
      });
    }
  }
};
</script>

<style scoped>
.ai-model-container {
  width: 100%;
  max-width: 800px;
  margin: 0 auto;
  height: 90vh;
  display: flex;
  flex-direction: column;
}

.chat-container {
  flex: 1;
  overflow-y: auto;
  background-color: #f7f7f7;
  padding: 20px;
  border-radius: 10px;
  margin-bottom: 20px;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
}

.messages {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.message {
  display: flex;
  align-items: flex-start;
}

.user-message {
  justify-content: flex-end;
}

.ai-message {
  justify-content: flex-start;
}

.message-content {
  padding: 10px;
  background-color: #e1e1e1;
  border-radius: 15px;
  max-width: 80%;
  word-wrap: break-word;
}

.user-message .message-content {
  background-color: #409eff;
  color: white;
}

.input-container {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px;
}

.input-box {
  width: 80%;
  margin-right: 10px;
}

.send-btn {
  width: 15%;
  background-color: #409eff;
  color: white;
}
</style>