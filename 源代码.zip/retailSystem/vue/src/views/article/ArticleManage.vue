<script>
import { Message, MessageBox } from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
import Navi from "@/components/Navi";
import { quillEditor } from 'vue-quill-editor';
import 'quill/dist/quill.core.css';
import 'quill/dist/quill.snow.css';
import 'quill/dist/quill.bubble.css';

import {
    articleCategoryListService,
    articleListService,
    articleAddService,
    articleDeleteService
} from '@/api/article.js';

export default {
    name: "ArticleManage",
    components: {
        Navi,
        quillEditor
    },
    data() {
        return {
            categorys: [],
            articles: [],
            categoryId: '',
            state: '',
            pageNum: 1,
            pageSize: 3,
            total: 0,
            visibleDrawer: false,
            articleModel: {
                title: '',
                categoryId: '',
                coverImg: '',
                content: '',
                state: ''
            }
        };
    },
    methods: {
        // 获取文章分类
        // async articleCategoryList() {
        //     try {
        //         const result = await articleCategoryListService(); // 调用接口
        //         this.categorys = result.data; // 确保返回的数据正确
        //     } catch (error) {
        //         console.error('获取文章分类失败:', error); // 错误处理
        //     }
        // }
        // 获取文章分类
        async articleCategoryList() {
            const userId = 1;  // 假设这里是已登录用户的 userId，替换为实际的值
            try {
                const result = await articleCategoryListService(userId);  // 传递 userId
                this.categorys = result.data; // 确保返回的数据正确
            } catch (error) {
                console.error('获取文章分类失败:', error); // 错误处理
            }
        }

        ,
        // 获取文章列表
        // async articleList() {
        //     const params = {
        //         pageNum: this.pageNum,
        //         pageSize: this.pageSize,
        //         categoryId: this.categoryId || null,
        //         state: this.state || null
        //     };
        //     try {
        //         const result = await articleListService(params); // 调用接口
        //         this.total = result.data.total;
        //         this.articles = result.data.items.map(article => {
        //             const category = this.categorys.find(c => c.id === article.categoryId);
        //             return { ...article, categoryName: category ? category.categoryName : '' };
        //         });
        //     } catch (error) {
        //         console.error('获取文章列表失败:', error); // 错误处理
        //     }
        // }
        // 获取文章列表
        async articleList() {
            const params = {
                pageNum: this.pageNum,
                pageSize: this.pageSize,
                // 在初始加载时不传递 categoryId 和 state
            };

            try {
                const result = await articleListService(params);
                this.total = result.data.total;
                this.articles = result.data.items;
            } catch (error) {
                console.error('获取文章列表失败:', error); // 错误处理
            }
        }

        ,
        // 添加文章
        async addArticle(clickState) {
            this.articleModel.state = clickState;
            try {
                const result = await articleAddService(this.articleModel); // 调用接口
                Message.success(result.msg || '添加成功');
                this.visibleDrawer = false;
                this.articleList();
            } catch (error) {
                console.error('添加文章失败:', error); // 错误处理
            }
        },
        // 编辑文章
        editArticle(row) {
            this.articleModel = { ...row };
            this.visibleDrawer = true;
        },
        // 删除文章
        async deleteArticle(row) {
            try {
                const result = await articleDeleteService(row.id); // 调用接口
                Message.success(result.msg || '删除成功');
                this.articleList();
            } catch (error) {
                console.error('删除文章失败:', error); // 错误处理
            }
        },
        // 页码变化
        onSizeChange(size) {
            this.pageSize = size;
            this.articleList();
        },
        onCurrentChange(num) {
            this.pageNum = num;
            this.articleList();
        }
    },
    mounted() {
        this.articleCategoryList();
        this.articleList();
    }
};
</script>

<template>
    <div class="container">
        <Navi></Navi>
        <el-card class="page-container">
            <template #header>
                <div class="header">
                    <span>文章管理</span>
                    <div class="extra">
                        <el-button type="primary" @click="visibleDrawer = true">添加文章</el-button>
                    </div>
                </div>
            </template>

            <!-- 搜索表单 -->
            <el-form inline>
                <el-form-item label="文章分类：">
                    <el-select placeholder="请选择" v-model="categoryId">
                        <el-option v-for="c in categorys" :key="c.id" :label="c.categoryName" :value="c.id"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="发布状态：">
                    <el-select placeholder="请选择" v-model="state">
                        <el-option label="已发布" value="已发布"></el-option>
                        <el-option label="草稿" value="草稿"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item>
                    <el-button type="primary" @click="articleList">搜索</el-button>
                    <el-button @click="categoryId = ''; state = ''">重置</el-button>
                </el-form-item>
            </el-form>

            <!-- 文章列表 -->
            <el-table :data="articles" style="width: 100%">
                <el-table-column label="文章标题" prop="title" width="400"></el-table-column>
                <el-table-column label="分类" prop="categoryName"></el-table-column>
                <el-table-column label="发表时间" prop="createTime"></el-table-column>
                <el-table-column label="状态" prop="state"></el-table-column>
                <el-table-column label="操作" width="100">
                    <template slot-scope="{ row }">
                        <el-button icon="el-icon-edit" circle plain type="primary" @click="editArticle(row)"></el-button>
                        <el-button icon="el-icon-delete" circle plain type="danger" @click="deleteArticle(row)"></el-button>
                    </template>
                </el-table-column>
                <template slot="empty">
                    <el-empty description="没有数据" />
                </template>
            </el-table>

            <!-- 分页条 -->
            <el-pagination v-model:current-page="pageNum" v-model:page-size="pageSize" :page-sizes="[3, 5, 10, 15]"
                layout="jumper, total, sizes, prev, pager, next" background :total="total" @size-change="onSizeChange"
                @current-change="onCurrentChange" style="margin-top: 20px; justify-content: flex-end" />

            <!-- 抽屉 -->
            <el-drawer v-model="visibleDrawer" title="添加文章" direction="rtl" size="50%">
                <el-form :model="articleModel" label-width="100px">
                    <el-form-item label="文章标题">
                        <el-input v-model="articleModel.title" placeholder="请输入标题"></el-input>
                    </el-form-item>
                    <el-form-item label="文章分类">
                        <el-select placeholder="请选择" v-model="articleModel.categoryId">
                            <el-option v-for="c in categorys" :key="c.id" :label="c.categoryName" :value="c.id"></el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item label="文章内容">
                        <quill-editor v-model="articleModel.content"></quill-editor>
                    </el-form-item>
                    <el-form-item>
                        <el-button type="primary" @click="addArticle('已发布')">发布</el-button>
                        <el-button type="info" @click="addArticle('草稿')">草稿</el-button>
                    </el-form-item>
                </el-form>
            </el-drawer>
        </el-card>
    </div>
</template>

<style scoped>
.page-container {
    min-height: 100%;
    box-sizing: border-box;

    .header {
        display: flex;
        align-items: center;
        justify-content: space-between;
    }
}
</style>
