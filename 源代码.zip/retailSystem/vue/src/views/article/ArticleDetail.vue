<template>
    <div class="article-page">
        <Navi></Navi>
        <!-- 顶部标题栏 -->
        <div class="article-header" v-if="article">
            <h1 class="title">{{ article.title }}</h1>
            <div class="author-info">
                <!-- 头像：使用动态路径 -->
                <img :src="getAuthorAvatar()" alt="作者头像" class="avatar" />
                <span class="author-name">{{ author.username || '未知用户' }} </span>
                <span class="publish-date">————{{ formatDate(article.updateTime) }}</span>
                <!-- 分享按钮 -->
                <div class="share-buttons">
                    <span class="share-label">&nbsp;&nbsp;分享到：</span>
                    <button @click="shareTo('weibo')">微博</button>
                    <button @click="shareTo('wechat')">微信</button>
                    <button @click="shareTo('qq')">QQ</button>
                </div>
            </div>
        </div>

        <!-- 如果没有文章，显示加载中 -->
        <div v-else>
            <p>加载中...</p>
        </div>

        <!-- 阅读进度条 -->
        <div class="reading-progress" :style="{ width: readingProgress + '%' }"></div>

        <div class="content-wrapper" v-if="article">
            <!-- 主体内容 -->
            <div class="article-content">
                <p v-html="article.content"></p>
                <div class="tags">
                    <span v-for="tag in article.tags" :key="tag" class="tag">{{ tag }}</span>
                </div>
                <!-- 推荐到的URL -->
                <div class="recommended-product">
                    <h3>推荐商品：</h3>
                    <a :href="article.command" target="_blank" class="product-link">
                        点击查看推荐商品
                    </a>
                </div>


                <!-- 评论区 -->
                <div class="comments-section">
                    <h3>评论区</h3>
                    <ul>
                        <li v-for="comment in comments" :key="comment.id" class="comment-item">
                            <div class="comment-content">{{ comment.content }}</div>
                            <div class="comment-meta">
                                <div class="comment-author">用户{{ comment.userId }}</div>
                                <div class="comment-time">{{ formatDate(comment.createTime) }}</div>
                            </div>
                        </li>
                    </ul>
                    <textarea v-model="newComment" placeholder="写下你的评论"></textarea>
                    <button @click="addComment">发表评论</button>
                </div>
            </div>
        </div>
    </div>
</template>


<script>
import axios from 'axios';
import Navi from "@/components/Navi";
export default {
    name: 'ArticleDetail',
    components: {
        Navi
    },
    data() {
        return {
            article: null, // 初始化为 null，后续加载文章内容
            author: null,   // 保存作者信息
            comments: [],   // 评论列表
            newComment: '', // 新评论内容
            relatedArticles: [], // 相关文章
            readingProgress: 0, // 阅读进度
            shareLink: "https://yourwebsite.com/article/1", // 分享链接
        };
    },
    mounted() {
        this.fetchArticleDetail(); // 加载文章内容
        this.fetchComments(); // 加载评论列表
        window.addEventListener('scroll', this.updateReadingProgress); // 更新阅读进度
    },
    beforeDestroy() {
        window.removeEventListener('scroll', this.updateReadingProgress); // 移除滚动监听
    },
    methods: {
        // 获取文章内容
        async fetchArticleDetail() {
            const articleId = this.$route.params.id;
            try {
                const response = await axios.get(`http://localhost:9090/retaildemo/article/${articleId}`);
                if (response.data) {
                    this.article = response.data; // 设置文章数据
                    // 获取文章作者的详细信息
                    this.fetchAuthorDetails(this.article.userId);
                    // console.log(this.article);
                } else {
                    alert('未找到该文章');
                }
            } catch (error) {
                console.error('获取文章详情失败:', error);
                alert('文章加载失败，请稍后再试');
            }
        },

        // 获取文章作者的详细信息
        async fetchAuthorDetails(userId) {
            try {
                const response = await axios.get(`http://localhost:9090/retaildemo/user/query/${userId}`);
                if (response.data) {
                    this.author = response.data;  // 保存作者信息
                } else {
                    this.author = { username: '未知用户', userImg: 'default.png' }; // 提供默认值
                }
            } catch (error) {
                console.error('获取作者信息失败:', error);
                this.author = { username: '未知用户', userImg: 'default.png' }; // 提供默认值
            }
        },


        // 获取评论列表
        async fetchComments() {
            const articleId = this.$route.params.id; // 使用当前文章 ID 加载评论
            try {
                const response = await axios.get(`http://localhost:9090/retaildemo/article/${articleId}/comments`);
                if (response.data) {
                    this.comments = response.data;  // 更新评论列表
                } else {
                    alert('加载评论失败');
                }
            } catch (error) {
                console.error('获取评论失败:', error);
                alert('评论加载失败，请稍后再试');
            }
        },

        // 获取作者头像，处理默认头像
        getAuthorAvatar() {
            return this.author && this.author.userImg
                ? require(`@/img/UserImg/${this.author.userImg}`)
                : require('@/img/default.png'); // 默认头像
        },

        // 添加评论
        async addComment() {
            if (!this.newComment.trim()) return;  // 防止提交空评论

            const commentData = {
                articleId: this.article.id,  // 当前文章的 ID
                userId: 32,  // 假设当前用户 ID 是 32，你可以根据用户登录信息动态获取
                content: this.newComment,    // 评论内容
                parentId: null,  // 父评论 ID，如果是顶级评论则为 null
            };

            try {
                // 调用后端接口提交评论
                const response = await axios.post(`http://localhost:9090/retaildemo/article/${this.article.id}/comment`, commentData);

                if (response.data.code === 10000) {
                    // 评论成功后清空评论框
                    this.newComment = '';
                    // 更新评论列表（重新从服务器获取）
                    this.fetchComments();
                    alert('评论成功！');
                } else {
                    alert('评论失败，请稍后再试');
                }
            } catch (error) {
                console.error('添加评论失败:', error);
                alert('评论失败，请稍后再试');
            }
        },

        // 分享功能
        shareTo(platform) {
            this.copyToClipboard(this.shareLink);
            let platformName = '';
            if (platform === 'weibo') {
                platformName = '微博';
            } else if (platform === 'wechat') {
                platformName = '微信';
            } else if (platform === 'qq') {
                platformName = 'QQ';
            }
            alert(`${platformName}分享链接已复制到粘贴板！`);
        },

        // 复制内容到剪贴板
        copyToClipboard(text) {
            const textarea = document.createElement('textarea');
            textarea.value = text;
            document.body.appendChild(textarea);
            textarea.select();
            document.execCommand('copy');
            document.body.removeChild(textarea);
        },

        // 更新阅读进度
        updateReadingProgress() {
            const scrollTop = window.scrollY || document.documentElement.scrollTop;
            const scrollHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;
            this.readingProgress = Math.min((scrollTop / scrollHeight) * 100, 100);
        },

        // 格式化日期
        formatDate(date) {
            if (!date) return '未知时间';  // 如果日期无效，返回默认文本
            const parsedDate = new Date(date);  // 将日期字符串转换为 Date 对象
            if (isNaN(parsedDate)) return '未知时间';  // 如果解析失败，返回默认文本

            const year = parsedDate.getFullYear();
            const month = String(parsedDate.getMonth() + 1).padStart(2, '0');  // 月份需要加1，且要补齐两位
            const day = String(parsedDate.getDate()).padStart(2, '0');
            const hours = String(parsedDate.getHours()).padStart(2, '0');
            const minutes = String(parsedDate.getMinutes()).padStart(2, '0');

            return `${year}-${month}-${day} ${hours}:${minutes}`;  // 返回 "YYYY-MM-DD HH:MM" 格式
        }
    },
};
</script>
<style scoped>
/* 全局样式 */
.article-page {
    font-family: 'Arial', sans-serif;
    line-height: 1.6;
    color: #333;
    padding: 0 20px;
    /* 添加左右内边距，避免内容紧贴边缘 */
}

.article-header {
    position: relative;
    border-bottom: 1px solid #eee;
    padding-bottom: 20px;
    margin-bottom: 20px;
}

.article-header .title {
    font-size: 2rem;
    margin: 0;
    font-weight: bold;
    /* 强调文章标题 */
}

.author-info {
    display: flex;
    align-items: center;
    margin-top: 10px;
    font-size: 0.9rem;
    color: #666;
}

.author-info .avatar {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    margin-right: 10px;
}

.share-buttons {
    margin-left: auto;
    /* 使用自动边距来让分享按钮对齐到右边 */
    display: flex;
    align-items: center;
}

.share-buttons span {
    margin-right: 10px;
    font-size: 0.9rem;
    color: #333;
}

.share-buttons button {
    padding: 5px 10px;
    font-size: 0.9rem;
    cursor: pointer;
    border: 1px solid #ccc;
    background: #fff;
}

.share-buttons button:hover {
    background-color: #f1f1f1;
}

/* 阅读进度条 */
.reading-progress {
    position: fixed;
    top: 0;
    left: 0;
    height: 4px;
    background: #007bff;
    z-index: 9999;
}

/* 文章内容区域 */
.content-wrapper {
    max-width: 900px;
    /* 限制文章内容的最大宽度 */
    margin: 0 auto;
    /* 使内容水平居中 */
}

.article-content {
    padding: 20px 0;
    /* 添加上下内边距 */
}

.article-content .tags {
    margin-top: 20px;
    display: flex;
    flex-wrap: wrap;
}

.article-content .tag {
    background-color: #f1f1f1;
    padding: 5px 10px;
    margin-right: 10px;
    margin-bottom: 10px;
    border-radius: 15px;
    font-size: 0.9rem;
    color: #333;
}

/* 评论区 */
.comments-section {
    margin-top: 30px;
    padding-top: 20px;
    border-top: 1px solid #eee;
}

.comments-section h3 {
    color: violet;
    font-size: 1.5rem;
    font-weight: bold;
}

.comments-section ul {
    list-style-type: none;
    padding: 0;
}

.comments-section li {
    background-color: whitesmoke;
}

.comments-section .comment-item {
    margin-bottom: 15px;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    /* 评论内容靠左 */
}

.comments-section .comment-content {
    font-size: 1rem;
    color: #333;
}

.comments-section .comment-meta {
    font-size: 0.85rem;
    color: #777;
    display: flex;
    justify-content: space-between;
    width: 100%;
    margin-top: 5px;
}

.comments-section .comment-author {
    font-weight: bold;
}

.comments-section .comment-time {
    font-style: italic;
}

.comments-section textarea {
    width: 100%;
    height: 80px;
    margin-top: 10px;
    margin-bottom: 10px;
    padding: 10px;
    font-size: 1rem;
    border: 1px solid #ccc;
    border-radius: 5px;
    box-sizing: border-box;
    /* 确保内边距不影响整体宽度 */
}

.recommended-product {
    margin: 20px 0;
    padding: 15px;
    background-color: #f9f9f9;
    border-radius: 5px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.recommended-product h3 {
    margin-bottom: 10px;
    font-size: 18px;
    font-weight: bold;
}

.product-link {
    color: #007bff;
    font-size: 16px;
    text-decoration: none;
    font-weight: bold;
}

.product-link:hover {
    text-decoration: underline;
}

.comments-section button {
    padding: 5px 15px;
    background: #007bff;
    color: #fff;
    border: none;
    cursor: pointer;
    border-radius: 5px;
}

.comments-section button:hover {
    background: #0056b3;
}
</style>
