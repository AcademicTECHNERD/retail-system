<template>
  <div>
    <!-- 头部搜索栏和添加商品按钮 -->
    <el-header style="display: flex; justify-content: space-between; align-items: center;">
      <el-input v-model="searchQuery" placeholder="搜索商品..." @input="searchProducts" style="width: 300px;" />
      <el-button type="primary" @click="addProduct">添加商品</el-button>
    </el-header>

    <el-row>
      <!-- 左侧商品列表 -->
      <el-col :span="14">
        <el-table :data="filteredProducts" style="width: 80%" border>
          <el-table-column prop="name" label="商品名" width="180"></el-table-column>
          <el-table-column prop="sales" label="销量" width="100"></el-table-column>
          <el-table-column prop="stock" label="库存" width="100"></el-table-column>
          <el-table-column prop="sellPrice" label="价格" width="100"></el-table-column>
          <el-table-column prop="originalPrice" label="原价" width="100"></el-table-column>
          <el-table-column prop="discount" label="折扣" width="100"></el-table-column>
          <el-table-column label="操作" width="120">
            <template v-slot="{ row }">
              <el-button type="text" @click="viewProductDetail(row.id)">查看</el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-col>

      <!-- 右侧销售图表 -->
      <el-col :span="10">
        <el-card>
          <div id="salesChart" style="height: 500px;"></div>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import * as echarts from "echarts";
import axios from "axios";

export default {
  name: "MerchantHome",
  data() {
    return {
      searchQuery: "",
      products: [], // 商品列表，后端返回 MerchantProductVO 数组
      salesChart: null, // ECharts 图表对象
    };
  },
  computed: {
    // 根据搜索关键字过滤商品
    filteredProducts() {
      const filtered = this.products.filter((p) =>
        p.name.includes(this.searchQuery)
      );
      console.log("filteredProducts:", filtered);
      return filtered;
    },
  },
  mounted() {
    this.fetchProducts(); // 获取商品数据

    // 输出 localStorage 中的所有键值对
    console.log('当前 localStorage 内容:');
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      const value = localStorage.getItem(key);
      console.log(`${key}: ${value}`);
    }

    // 示例：获取并输出特定的用户登录数据
    const userInfoString = localStorage.getItem('userInfo');
    if (userInfoString) {
      try {
        const userInfo = JSON.parse(userInfoString);
        console.log('用户登录数据:', userInfo);
      } catch (error) {
        console.error('解析 userInfo 时发生错误:', error);
      }
    } else {
      console.log('未找到用户登录数据');
    }
  },
  methods: {
    // 获取商品数据，添加了详细的 console.log 调试信息
    async fetchProducts() {
      try {
        const merchant_id = localStorage.getItem("merchant_id") || 1;
        console.log("merchant_id from localStorage:", merchant_id);
        const response = await axios.get("http://localhost:9090/merchantmanage/goods/all", {
          params: { merchant_id },
        });
        console.log("Response from backend:", response.data);
        if (response.data.code === 10000) {
          const rawData = response.data.data;
          console.log("Raw data:", rawData);
          // 后端直接返回一个 MerchantProductVO 数组
          this.products = rawData;
          console.log("Mapped products:", this.products);
          this.initChart(); // 重新绘制图表
        } else {
          console.error("获取商品数据失败:", response.data.msg);
        }
      } catch (error) {
        console.error("请求失败:", error);
      }
    },

    // 初始化 ECharts 图表，并输出调试信息
    initChart() {
      if (!this.salesChart) {
        this.salesChart = echarts.init(document.getElementById("salesChart"));
      }
      const productNames = this.products.map((p) => p.name);
      const productSales = this.products.map((p) => p.sales);
      console.log("Chart X-Axis (names):", productNames);
      console.log("Chart Series (sales):", productSales);
      this.salesChart.setOption({
        title: { text: "总销售情况" },
        xAxis: {
          type: "category",
          data: productNames,
        },
        yAxis: { type: "value" },
        series: [
          {
            type: "bar",
            data: productSales,
          },
        ],
      });
    },

    // 搜索商品（filteredProducts 计算属性自动更新，同时输出当前搜索关键字）
    searchProducts() {
      console.log("搜索关键字:", this.searchQuery);
    },

    // 查看商品详情，增加调试信息
    viewProductDetail(productId) {
      console.log("查看商品详情，商品ID:", productId);
      this.$router.push({ path: `/product/${productId}` });
    },

    // 添加新商品，增加调试信息
    addProduct() {
      console.log("跳转到添加商品页面");
      this.$router.push({ path: "/addProduct" });
    },
  },
};
</script>

<style scoped>
/* 页面整体样式 */
.merchant-home {
  padding: 20px;
}

/* 头部样式 */
.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: #fff;
  padding: 10px 20px;
  border-radius: 5px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

/* 搜索输入框 */
.search-input {
  width: 300px;
}

/* 添加商品按钮 */
.add-btn {
  background-color: #409eff;
  border-color: #409eff;
  color: white;
}

/* 内容区域 */
.content {
  margin-top: 20px;
  display: flex;
  gap: 20px;
}

/* 商品列表 */
.product-list {
  background: white;
  padding: 20px;
  border-radius: 5px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  float: left;
}

/* 图表容器 */
.chart-container {
  background: white;
  padding: 20px;
  /* margin-right: 30px; */
  border-radius: 5px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);

}

/* ECharts 图表样式 */
.chart {
  height: 300px;
  width: 80%;
  margin-right: 30px;
}
</style>
