<template>
    <el-row style="width: 80%; margin: 0 auto; background-color: white">
        <el-row>
            <div style="float: left; margin: 5px">
                <h2>搜索结果</h2>
            </div>
        </el-row>

        <!-- 遍历展示商品 -->
        <el-col :span="6" v-for="product in products" :key="product.productId">
            <el-card style="border-radius: 15px; margin: 5px" shadow="hover">
                <el-row>
                    <!-- 商品图片 -->
                    <router-link class="product-img" :to="{ name: 'Product', query: { pid: product.productId } }">
                        <!-- 渲染商品图片 -->
                        <img :src="getImageUrl(product.imageUrl)" style="width: 100%; height: 100%; display: block;" />
                    </router-link>
                </el-row>

                <el-row>
                    <router-link :to="{ name: 'Product', query: { pid: product.productId } }">
                        <span style="float: left; font-size: 16px; color: #333333">{{ product.productName | cut }}</span>
                    </router-link>
                </el-row>

                <el-row>
                    <span style="float: left; font-size: 10px; color: rgb(153, 153, 153)">
                        {{ product.content | ellipsis }}
                    </span>
                </el-row>
            </el-card>
        </el-col>
    </el-row>
</template>
  
<script>
import axios from "axios";

export default {
    name: "SearchList",
    data() {
        const productsString = this.$route.query.products;
        console.log("Encoded products:", productsString);  // 打印原始 URL 参数
        const decodedString = decodeURIComponent(productsString);
        console.log("Decoded products:", decodedString);  // 打印解码后的字符串
        return {
            // 先进行解码再解析 JSON 数据
            products: this.parseProducts(decodedString || "[]"),
        };
    },
    filters: {
        cut(value) {
            if (!value) return "商品名为空";
            if (value.length > 10) {
                return value.slice(0, 10) + "...";
            }
            return value;
        },
        ellipsis(value) {
            if (!value) return "暂无说明";
            if (value.length > 13) {
                return value.slice(0, 13) + "...";
            }
            return value;
        },
    },
    methods: {
        // 解析 JSON 字符串
        parseProducts(productsString) {
            try {
                return JSON.parse(productsString); // 解析 JSON
            } catch (error) {
                console.error("解析出错:", error);
                return [];
            }
        },

        // 请求商品详细信息
        fetchProductDetail(productId) {
            // 获取详细商品信息的接口 URL
            const url = `/retaildemo/products/product/${productId}`;

            // 发送请求
            axios.get(url)
                .then(response => {
                    const productDetail = response.data.data.product;
                    console.log("商品详情：", productDetail);

                    // 获取商品图片并更新
                    this.updateProductImage(productId, productDetail.productImgs[0]?.url);  // 假设返回的图片列表有一个主图
                })
                .catch(error => {
                    console.error("获取商品详情失败:", error);
                });
        },

        // 更新产品图片 URL
        updateProductImage(productId, imageUrl) {
            const product = this.products.find(p => p.productId === productId);
            if (product) {
                product.imageUrl = imageUrl;  // 假设返回的图片 URL 是相对路径
            }
        },

        // 返回图片的路径（如果没有返回路径，则使用默认图片）
        getImageUrl(imageUrl) {
            if (!imageUrl) {
                return require("@/assets/logo.png");  // 默认图片
            }
            // 如果返回的是相对路径，直接使用
            return `/images/${imageUrl}`;
        },
    },

    // 在页面加载后，获取每个商品的详细信息（包括图片路径）
    mounted() {
        this.products.forEach(product => {
            // 根据每个商品的 productId 请求商品详情，获取图片等信息
            this.fetchProductDetail(product.productId);
        });
    },
};
</script>
  
<style scoped>
.product-img img {
    height: 242px;
}
</style>
  