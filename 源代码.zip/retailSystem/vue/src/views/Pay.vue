<template>

</template>

<script>
export default {
  name: "Pay"
}
</script>

<style scoped>

</style>