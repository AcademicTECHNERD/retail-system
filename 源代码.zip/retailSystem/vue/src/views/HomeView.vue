<template>
  <div class="container">
    <!-- 导航栏组件 -->
    <Navi></Navi>
    <wisdom></wisdom>
    <div>
      <div class="logo">
        <h1>基于前后端分离架构的导向型智慧商城</h1>
      </div>

      <div class="search">
        <input type="text" v-model="keyword" placeholder="请输入您要搜索的内容" />
        <button id="searchButton" @click="handleSearchClick">
          {{ isDeepClicked ? '深入' : '搜索' }}
        </button>
        <button id="AIsearch" @click="toAI">询问AI</button>
      </div>

      <section id="Question_Bubble" v-if="questions.length > 0">
        <div v-for="(question, index) in questions" :key="question.questionId" class="question"
          :class="{ 'selected': selectedOptions[index] }">
          <h3>{{ question.question }}</h3>
          <div class="options">
            <button v-for="(option, i) in JSON.parse(question.options)" :key="i" class="option"
              :class="{ selected: selectedOptions[index] === option }" @click="selectOption(index, option)">
              {{ option }}
            </button>
          </div>
        </div>
      </section>

      <div class="ToArtical">
        <a href="/ArticleHome" target="_blank" title="社区">
          我不知道什么款式适合我
        </a>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios';
import Navi from "../components/Navi";
import Wisdom from "../components/wisdom";

export default {
  name: "HomeView",
  components: {
    Navi,
    Wisdom
  },
  data() {
    return {
      isDeepClicked: false, // 用于判断是否点击了“深入”
      keyword: '', // 用户输入的搜索关键词
      selectedOptions: {}, // 存储每个问题的选中项
      questions: [], // 存储从后台获取的问题数据
      products: [] // 存储查询到的商品列表
    };
  },
  methods: {
    // 选择问题的答案
    selectOption(index, option) {
      this.$set(this.selectedOptions, index, option);
    },

    // 搜索点击事件
    handleSearchClick() {
      if (!this.isDeepClicked) {
        // 第一次点击"搜索"，获取问题泡数据
        this.isDeepClicked = true;

        // 获取用户输入的关键词，并发送到后端请求
        axios.get(`http://localhost:9090/api/search?keyword=${this.keyword}`)
          .then(response => {
            if (response.data.success) {
              // 后端返回的数据包含问题，我们将问题保存在 questions 中
              this.questions = response.data.questions;
            } else {
              // 如果没有找到相关问题，给出提示
              this.questions = [];
              alert('没有找到相关问题');
            }
          })
          .catch(error => {
            console.error('搜索失败:', error);
            alert('搜索请求失败，请稍后重试');
          });
      } else {
        // 第二次点击"深入"按钮时，进行二次查询
        const searchData = {
          keyword: this.keyword,  // 搜索关键词
          userAnswers: []  // 初始化 userAnswers 数组
        };

        // 假设问题选项有固定顺序（例如：brand, product_place, content），
        // 我们需要填充用户的答案。
        // 使用空字符串填充没有选择的答案
        const answers = [
          this.selectedOptions[0] || "",  // 第一个问题的选项（如果未选择，则为空）
          this.selectedOptions[1] || "",  // 第二个问题的选项（如果未选择，则为空）
          this.selectedOptions[2] || ""   // 第三个问题的选项（如果未选择，则为空）
        ];

        // 将这些答案填充到 searchData 的 userAnswers 中
        searchData.userAnswers = answers;

        // 发送二次请求到后台获取商品数据
        axios.post("http://localhost:9090/api/retaildemo/products/searchWithAnswers", searchData)
          .then(response => {
            if (response.data.code === 200) {
              // 如果有商品数据
              this.products = response.data.data;
              console.log(this.products);
              // 如果查询到商品，则跳转到商品详情页，传递 productId
              if (this.products.length > 0) {
                const productId = this.products[0].productId;  // 假设只取第一个商品
                this.$router.push({ name: 'SearchProduct', query: { id: productId } });
              } else {
                // 如果没有查询到商品，跳转到404页面
                this.$router.push({ name: 'NotFound' });
              }
            } else {
              // 查询失败或返回的没有商品数据
              this.products = [];
              this.$router.push({ name: 'NotFound' });
            }
          })
          .catch(error => {
            console.error('查询失败:', error);
            alert('查询请求失败，请稍后重试');
          });
      }
    },
    // 跳转到AI模型页面
    toAI() {
      this.$router.push({ path: '/AI_model' });
    }
  }

};
</script>



<style scoped>
/* 重置body和html，避免出现横向滚动条 */
html,
body {
  overflow-x: hidden;
  width: 100vw;
  margin: 0;
  padding: 0;
}

.container {
  width: 100%;
  height: 100vh;
  /* 设置高度为视口高度 */
  background: linear-gradient(rgba(0, 0, 0, 0.3),
      /* 渐变的颜色和透明度 */
      rgba(0, 0, 0, 0.3)), url('../assets/bg.jpg');
  /* 背景图片路径 */
  background-size: cover;
  background-position: center;
  background-attachment: fixed;
}

#header-ul {
  list-style-type: none;
  display: flex;
  padding: 0;
  margin: 0;
  width: 100%;
}

#header-ul li {
  margin-right: 15px;
}

#header-ul a {
  text-decoration: none;
}

#header-ul a:hover {
  color: #dc3545;
}

.logo {
  width: 600px;
  height: 100px;
  margin: 0 auto;
}

.logo h1 {
  color: aquamarine;
  line-height: 100px;
}

.search {
  width: 510px;
  height: 100px;
  margin: 0 auto;
  display: flex;
  align-items: center;
}

.search input {
  border-radius: 20px;
  width: 300px;
  height: 50px;
  padding-left: 10px;
  margin-right: 10px;
}

.search button {
  border-radius: 10px;
  padding: 10px 20px;
  background-color: #007bff;
  color: white;
  border: none;
  height: 50px;
  margin-right: 10px;
}

.search button:hover {
  background-color: #0056b3;
}

.search button:active {
  background-color: #004494;
  transform: scale(0.95);
}

/* 美化AIsearch按钮 */
#AIsearch {
  border-radius: 10px;
  padding: 10px 20px;
  background-color: #28a745;
  color: white;
  border: none;
  height: 50px;
  transition: background-color 0.3s, transform 0.3s;
}

#AIsearch:hover {
  background-color: #218838;
}

#AIsearch:active {
  background-color: #1e7e34;
  transform: scale(0.95);
}

#Question_Bubble {
  display: flex;
  justify-content: space-between;
  height: 300px;
  width: 100%;
}

#Question_Bubble .left,
#Question_Bubble .mid,
#Question_Bubble .right {
  flex: 1;
  height: 250px;
  border-radius: 50%;
  margin-left: 10px;
  opacity: 0;
  position: relative;
  top: 100px;
  transition: opacity 0.5s ease-out, top 0.5s ease-out;
}

#Question_Bubble h3 {
  text-align: center;
}

.options {
  display: flex;
  flex-direction: column;
  gap: 10px;
  width: 374px;
  margin-left: 165px;
  text-align: center;
}

.option {
  width: 200px;
  padding: 10px;
  background-color: #f0f0f0;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  transition: background-color 0.3s;
}

.option:hover {
  background-color: pink;
}

.option.selected {
  background-color: #4caf50;
  color: white;
}

.ToArtical {
  height: 50px;
}

.ToArtical a {
  display: block;
  width: 200px;
  height: 50px;
  line-height: 50px;
  text-align: center;
  background-color: yellowgreen;
  color: white;
  border-radius: 10px;
  margin: 0 auto;
  margin-top: 20px;
  text-decoration: none;
}
</style>
